// inject by extensions hot-update ---- start ----
jsb.fileUtils.addSearchPath(jsb.fileUtils.getWritablePath() + "hotupdate_storage/src/", true);
jsb.fileUtils.addSearchPath(jsb.fileUtils.getWritablePath() + "hotupdate_storage/jsb-adapter/", true);
jsb.fileUtils.addSearchPath(jsb.fileUtils.getWritablePath() + "hotupdate_storage/", true);
// inject by extensions hot-update ---- end ----

// SystemJS support.
window.self = window;
require("src/system.bundle.js");   // ⚡ giờ chắc chắn sẽ tìm được trong hotupdate_storage/src/

const importMapJson = jsb.fileUtils.getStringFromFile("src/import-map.json");
const importMap = JSON.parse(importMapJson);
System.warmup({
    importMap,
    importMapUrl: 'src/import-map.json',
    defaultHandler: (urlNoSchema) => {
        require(urlNoSchema.startsWith('/') ? urlNoSchema.substr(1) : urlNoSchema);
    },
});

System.import('./src/application.js')
.then(({ Application }) => {
    return new Application();
}).then((application) => {
    return System.import('cc').then((cc) => {
        require('jsb-adapter/engine-adapter.js');
        return application.init(cc);
    }).then(() => {
        return application.start();
    });
}).catch((err) => {
    console.error(err.toString() + ', stack: ' + err.stack);
});
