// SystemJS support.
window.self = window;
require("src/system.bundle.js");

try {
    const importMapJson = jsb.fileUtils.getStringFromFile("src/import-map.json");
    const importMap = JSON.parse(importMapJson);

    console.log("Loaded import-map.json:", importMapJson);
    console.log("Parsed import map:", importMap);

    System.warmup({
        importMap,
        importMapUrl: 'src/import-map.json',
        defaultHandler: (urlNoSchema) => {
            console.log("Require via defaultHandler:", urlNoSchema);
            require(urlNoSchema.startsWith('/') ? urlNoSchema.substr(1) : urlNoSchema);
        },
    });

    const tryImportApplication = (path) => {
        console.log("Trying to import Application from:", path);
        return System.import(path)
            .then(({ Application }) => {
                if (!Application) {
                    throw new Error("Application export not found in " + path);
                }
                console.log("Application loaded from", path);
                return new Application();
            });
    };

    // Try ./application.js first, fallback to ./src/application.js
    tryImportApplication('./application.js')
        .catch(err => {
            console.warn("Failed to load ./application.js, error:", err);
            return tryImportApplication('./src/application.js');
        })
        .then((application) => {
            if (!application) throw new Error("Application could not be initialized");

            console.log("Application instance created");

            return System.import('cc').then((cc) => {
                console.log("CC imported");
                require('jsb-adapter/engine-adapter.js');
                return application.init(cc);
            }).then(() => {
                console.log("Starting application...");
                return application.start();
            });
        })
        .catch((err) => {
            console.error("Final startup error:", err.toString(), "\nStack:", err.stack);
        });

} catch (e) {
    console.error("Fatal error in main.js:", e.toString(), "\nStack:", e.stack);
}
