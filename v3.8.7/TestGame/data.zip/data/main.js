
(function () {
    if (typeof window.jsb === 'object') {
        var hotUpdateSearchPaths = localStorage.getItem('HotUpdateSearchPaths');
        if (hotUpdateSearchPaths) {
            var paths = JSON.parse(hotUpdateSearchPaths);
            jsb.fileUtils.setSearchPaths(paths);
            console.log("Current search paths after hot update:", JSON.stringify(paths));

            var fileList = [];
            var storagePath = paths[0] || '';
            var tempPath = storagePath + '_temp/';
            var baseOffset = tempPath.length;

            if (jsb.fileUtils.isDirectoryExist(tempPath) && !jsb.fileUtils.isFileExist(tempPath + 'project.manifest.temp')) {
                jsb.fileUtils.listFilesRecursively(tempPath, fileList);
                console.log("Files found in _temp:", fileList);

                fileList.forEach(srcPath => {
                    var relativePath = srcPath.substr(baseOffset);
                    var dstPath = storagePath + relativePath;

                    if (srcPath[srcPath.length - 1] == '/') {
                        cc.fileUtils.createDirectory(dstPath);
                        console.log("Created directory:", dstPath);
                    } else {
                        if (cc.fileUtils.isFileExist(dstPath)) {
                            cc.fileUtils.removeFile(dstPath);
                            console.log("Removed old file:", dstPath);
                        }
                        cc.fileUtils.renameFile(srcPath, dstPath);
                        console.log("Moved file:", srcPath, "->", dstPath);
                    }
                });

                cc.fileUtils.removeDirectory(tempPath);
                console.log("Removed temporary directory:", tempPath);
            } else {
                console.log("No _temp directory found or project.manifest.temp exists, skipping move.");
            }
        } else {
            console.log("No HotUpdateSearchPaths found in localStorage.");
        }
    } else {
        console.log("jsb object not found, skipping hot update handling.");
    }
})();



// SystemJS support.
window.self = window;
require("src/system.bundle.js");

const importMapJson = jsb.fileUtils.getStringFromFile("src/import-map.json");
const importMap = JSON.parse(importMapJson);
System.warmup({
    importMap,
    importMapUrl: 'src/import-map.json',
    defaultHandler: (urlNoSchema) => {
        require(urlNoSchema.startsWith('/') ? urlNoSchema.substr(1) : urlNoSchema);
    },
});

System.import('./application.js')
.then(({ Application }) => {
    return new Application();
}).then((application) => {
    return System.import('cc').then((cc) => {
        require('jsb-adapter/engine-adapter.js');
        return application.init(cc);
    }).then(() => {
        return application.start();
    });
}).catch((err) => {
    console.error(err.toString() + ', stack: ' + err.stack);
});
