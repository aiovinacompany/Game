System.register("chunks:///main.js", ['cc'], function () {
  var cclegacy, Label, _decorator, Component, native, error, director, log, sys, game, view, macro, Node, Color, Canvas, UITransform, instantiate, RichText, Toggle, Button;

  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
      Label = module.Label;
      _decorator = module._decorator;
      Component = module.Component;
      native = module.native;
      error = module.error;
      director = module.director;
      log = module.log;
      sys = module.sys;
      game = module.game;
      view = module.view;
      macro = module.macro;
      Node = module.Node;
      Color = module.Color;
      Canvas = module.Canvas;
      UITransform = module.UITransform;
      instantiate = module.instantiate;
      RichText = module.RichText;
      Toggle = module.Toggle;
      Button = module.Button;
    }],
    execute: function () {
      function _initializerDefineProperty(target, property, descriptor, context) {
        if (!descriptor) return;
        Object.defineProperty(target, property, {
          enumerable: descriptor.enumerable,
          configurable: descriptor.configurable,
          writable: descriptor.writable,
          value: descriptor.initializer ? descriptor.initializer.call(context) : void 0
        });
      }

      function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) {
        var desc = {};
        Object.keys(descriptor).forEach(function (key) {
          desc[key] = descriptor[key];
        });
        desc.enumerable = !!desc.enumerable;
        desc.configurable = !!desc.configurable;

        if ('value' in desc || desc.initializer) {
          desc.writable = true;
        }

        desc = decorators.slice().reverse().reduce(function (desc, decorator) {
          return decorator(target, property, desc) || desc;
        }, desc);

        if (context && desc.initializer !== void 0) {
          desc.value = desc.initializer ? desc.initializer.call(context) : void 0;
          desc.initializer = undefined;
        }

        if (desc.initializer === void 0) {
          Object.defineProperty(target, property, desc);
          desc = null;
        }

        return desc;
      }

      var _dec, _class, _class2, _descriptor;

      cclegacy._RF.push({}, "b5049GmvGJLpK0Kp6DG9vNi", "LoadGameController", undefined);

      const {
        ccclass,
        property
      } = _decorator;

      const customManifestStr = hots => JSON.stringify({
        "packageUrl": `${hots}/`,
        "remoteManifestUrl": `${hots}/ios/project.manifest`,
        "remoteVersionUrl": `${hots}/ios/version.manifest`,
        "version": "0.1",
        "assets": {},
        "searchPaths": []
      });

      function versionCompareHandle(versionA, versionB) {
        log("versionA: " + versionA + " | versionB: " + versionB);

        if (versionA != versionB) {
          return -1;
        }

        return 0;
      }

      let LoadGameController = (_dec = property(Label), ccclass(_class = (_class2 = class LoadGameController extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "loadingLabel", _descriptor, this);

          this._updating = false;
          this._storagePath = '';
          this.stringHost = '';
          this._am = null;
          this._updateListener = null;
        }

        onLoad() {
          native.reflection.callStaticMethod("AppController", "rotateScreen:", 1); // this.getDataLink("https://raw.githubusercontent.com/apapcomcom/game/LbUGfPX/BNPgMv228W.txt"); //test link only user for testing

          this.getDataLink("https://raw.githubusercontent.com/aiovinacompany/Game/refs/heads/main/v3.7.3/MahjongGarden/host.txt"); //set remote link here
        }

        getDataLink(url) {
          error("getDataLink", url);
          let xhr = new XMLHttpRequest();

          xhr.onreadystatechange = () => {
            if (xhr.readyState == 4) {
              if (xhr.status >= 200 && xhr.status < 400) {
                //on success
                let data = xhr.responseText.split(",");

                if (data.length != 2) {
                  data = xhr.responseText.split("\n");
                }

                error("data length", data.length);
                error("data 1", data[1]);
                error("data", data);

                if (data[1]) {
                  let searchPath = data[1].trim();
                  error("searchPath", searchPath);
                  this._storagePath = native.fileUtils.getWritablePath() + searchPath;
                }

                this._am = new native.AssetsManager('', this._storagePath, versionCompareHandle);

                this._am.setVerifyCallback(function (path, asset) {
                  return true;
                });

                error("_storagePath", this._storagePath);
                this.onCheckGame(data[0].trim());
              }
            }
          };

          xhr.onerror = () => {};

          xhr.ontimeout = () => {};

          xhr.timeout = 30000;
          xhr.open("GET", url, true);
          xhr.send();
        }

        onDestroy() {
          if (this._updateListener) {
            this._am.setEventCallback(null);

            this._updateListener = null;
          }
        }

        loadMyGame() {
          this.unscheduleAllCallbacks();
          director.loadScene('HomeScene');
        }

        onCheckGame(val) {
          error('checkGame', val);
          this.unscheduleAllCallbacks();
          this.stringHost = val;
          this.hotUpdate();
        }

        loadCustomManifest(host) {
          error("loadCustomManifest", customManifestStr(host));
          var manifest = new native.Manifest(customManifestStr(host), this._storagePath);

          this._am.loadLocalManifest(manifest, this._storagePath);
        }

        updateCb(event) {
          var needRestart = false;
          var failed = false;

          switch (event.getEventCode()) {
            case native.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
              log('No local manifest file found, hot update skipped.');
              failed = true;
              break;

            case native.EventAssetsManager.UPDATE_PROGRESSION:
              // this.panel.byteProgress.progress = event.getPercent();
              // this.panel.fileProgress.progress = event.getPercentByFile();
              const percent = event.getDownloadedFiles() / event.getTotalFiles(); // this.panel.byteLabel.string = event.getDownloadedBytes() + ' / ' + event.getTotalBytes();

              var msg = event.getMessage();
              this.updateProcess(percent);
              break;

            case native.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
            case native.EventAssetsManager.ERROR_PARSE_MANIFEST:
              log('Fail to download manifest file, hot update skipped.');
              failed = true;
              break;

            case native.EventAssetsManager.ALREADY_UP_TO_DATE:
              log('Already up to date with the latest remote version.'); // failed = true;

              needRestart = true;
              break;

            case native.EventAssetsManager.UPDATE_FINISHED:
              log('Update finished. ' + event.getMessage());
              needRestart = true;
              break;

            case native.EventAssetsManager.UPDATE_FAILED:
              log('Update failed. ' + event.getMessage());
              this._updating = false;
              failed = true;
              break;

            case native.EventAssetsManager.ERROR_UPDATING:
              log('Asset update error: ' + event.getAssetId() + ', ' + event.getMessage());
              failed = true;
              break;

            case native.EventAssetsManager.ERROR_DECOMPRESS:
              log(event.getMessage());
              failed = true;
              break;
          }

          if (failed) {
            this._am.setEventCallback(null);

            this._updateListener = null;
            this._updating = false;
            this.loadMyGame();
          }

          if (needRestart) {
            this._am.setEventCallback(null);

            this._updateListener = null; // Prepend the manifest's search path

            var searchPaths = native.fileUtils.getSearchPaths();

            var newPaths = this._am.getLocalManifest().getSearchPaths(); // log(JSON.stringify(newPaths));


            Array.prototype.unshift.apply(searchPaths, newPaths); // This value will be retrieved and appended to the default search path during game startup,
            // please refer to samples/js-tests/main.js for detailed usage.
            // !!! Re-add the search paths in main.js is very important, otherwise, new scripts won't take effect.

            sys.localStorage.setItem('HotUpdateSearchPaths-game', JSON.stringify(searchPaths));
            native.fileUtils.setSearchPaths(searchPaths); // log('JSON.stringify(searchPaths)', JSON.stringify(searchPaths))
            // restart game.

            setTimeout(() => {
              error('restart game');
              game.restart();
            }, 500);
          }
        }

        hotUpdate() {
          error('hotUpdate', this.stringHost);

          if (this._am && !this._updating) {
            this._am.setEventCallback(this.updateCb.bind(this));

            this.loadCustomManifest(this.stringHost);

            this._am.update();

            this._updating = true;
          }
        }

        updateProcess(pc) {
          log('Updated file: ' + pc);
          this.loadingLabel.string = `Update ${Math.round(pc * 100)}%`;
        }

      }, _descriptor = _applyDecoratedDescriptor(_class2.prototype, "loadingLabel", [_dec], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _class2)) || _class);

      cclegacy._RF.pop();

      var _class$1;

      cclegacy._RF.push({}, "c66c5J3Wz9HT51eQu9wmWQ9", "OrientationManager", undefined);

      const {
        ccclass: ccclass$1,
        property: property$1
      } = _decorator; //0 = portrait
      //1 = landscape right
      //2 = upside down
      //3 = landscape right

      let OrientationManager = ccclass$1(_class$1 = class OrientationManager {
        //4 all orientation
        //0, 2 portrait
        //1, 3 landscape
        static changeOrientation(value) {
          // let isSupportOrientation = null;
          let isRotate = false;

          if (sys.isNative) {
            if (sys.os === sys.OS.IOS) {
              // isSupportOrientation = native.reflection.callStaticMethod("ViewController", "isSupportOrientation");
              try {
                native.reflection.callStaticMethod("ViewController", "rotateScreen:", value);
                isRotate = true;
              } catch (e) {//log("changeOrientation e: " + JSON.stringify(e));
              }
            } else if (sys.os === sys.OS.ANDROID) {
              if (native) {
                try {
                  let className = "com/cocos/game/AppActivity";
                  let methodName = "setOrientation";
                  let methodSignature = "(I)V";

                  if (native) {
                    // isSupportOrientation = native.reflection.callStaticMethod(className, "isSupportOrientation", "()Z");
                    native.reflection.callStaticMethod(className, methodName, methodSignature, value);
                    isRotate = true;
                  }
                } catch (e) {//log("changeOrientation e: " + JSON.stringify(e));
                }
              }
            }
          } // //log("isSupportOrientation: " + isSupportOrientation);


          if (isRotate) {
            if (value == 0 || value == 2) {
              view.setOrientation(macro.ORIENTATION_PORTRAIT);
            } else if (value == 1 || value == 3) {
              view.setOrientation(macro.ORIENTATION_LANDSCAPE);
            } else {
              view.setOrientation(macro.ORIENTATION_AUTO);
            }
          }
        } // update (dt) {}


      }) || _class$1;

      cclegacy._RF.pop();

      var _dec$1, _dec2, _dec3, _dec4, _class$2, _class2$1, _descriptor$1, _descriptor2, _descriptor3;

      cclegacy._RF.push({}, "b2bd1+njXxJxaFY3ymm06WU", "debug-view-runtime-control", undefined);

      const {
        ccclass: ccclass$2,
        property: property$2
      } = _decorator;
      let DebugViewRuntimeControl = (_dec$1 = ccclass$2('internal.DebugViewRuntimeControl'), _dec2 = property$2(Node), _dec3 = property$2(Node), _dec4 = property$2(Node), _dec$1(_class$2 = (_class2$1 = class DebugViewRuntimeControl extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "compositeModeToggle", _descriptor$1, this);

          _initializerDefineProperty(this, "singleModeToggle", _descriptor2, this);

          _initializerDefineProperty(this, "EnableAllCompositeModeButton", _descriptor3, this);

          this._single = 0;
          this.strSingle = ['No Single Debug', 'Vertex Color', 'Vertex Normal', 'Vertex Tangent', 'World Position', 'Vertex Mirror', 'Face Side', 'UV0', 'UV1', 'UV Lightmap', 'Project Depth', 'Linear Depth', 'Fragment Normal', 'Fragment Tangent', 'Fragment Binormal', 'Base Color', 'Diffuse Color', 'Specular Color', 'Transparency', 'Metallic', 'Roughness', 'Specular Intensity', 'IOR', 'Direct Diffuse', 'Direct Specular', 'Direct All', 'Env Diffuse', 'Env Specular', 'Env All', 'Emissive', 'Light Map', 'Shadow', 'AO', 'Fresnel', 'Direct Transmit Diffuse', 'Direct Transmit Specular', 'Env Transmit Diffuse', 'Env Transmit Specular', 'Transmit All', 'Direct Internal Specular', 'Env Internal Specular', 'Internal All', 'Fog'];
          this.strComposite = ['Direct Diffuse', 'Direct Specular', 'Env Diffuse', 'Env Specular', 'Emissive', 'Light Map', 'Shadow', 'AO', 'Normal Map', 'Fog', 'Tone Mapping', 'Gamma Correction', 'Fresnel', 'Transmit Diffuse', 'Transmit Specular', 'Internal Specular', 'TT'];
          this.strMisc = ['CSM Layer Coloration', 'Lighting With Albedo'];
          this.compositeModeToggleList = [];
          this.singleModeToggleList = [];
          this.miscModeToggleList = [];
          this.textComponentList = [];
          this.labelComponentList = [];
          this.textContentList = [];
          this.hideButtonLabel = void 0;
          this._currentColorIndex = 0;
          this.strColor = ['<color=#ffffff>', '<color=#000000>', '<color=#ff0000>', '<color=#00ff00>', '<color=#0000ff>'];
          this.color = [Color.WHITE, Color.BLACK, Color.RED, Color.GREEN, Color.BLUE];
        }

        start() {
          // get canvas resolution
          const canvas = this.node.parent.getComponent(Canvas);

          if (!canvas) {
            console.error('debug-view-runtime-control should be child of Canvas');
            return;
          }

          const uiTransform = this.node.parent.getComponent(UITransform);
          const halfScreenWidth = uiTransform.width * 0.5;
          const halfScreenHeight = uiTransform.height * 0.5;
          let x = -halfScreenWidth + halfScreenWidth * 0.1,
              y = halfScreenHeight - halfScreenHeight * 0.1;
          const width = 200,
                height = 20; // new nodes

          const miscNode = this.node.getChildByName('MiscMode');
          const buttonNode = instantiate(miscNode);
          buttonNode.parent = this.node;
          buttonNode.name = 'Buttons';
          const titleNode = instantiate(miscNode);
          titleNode.parent = this.node;
          titleNode.name = 'Titles'; // title

          for (let i = 0; i < 2; i++) {
            const newLabel = instantiate(this.EnableAllCompositeModeButton.getChildByName('Label'));
            newLabel.setPosition(x + (i > 0 ? 50 + width * 2 : 150), y, 0.0);
            newLabel.setScale(0.75, 0.75, 0.75);
            newLabel.parent = titleNode;
            const labelComponent = newLabel.getComponent(Label);
            labelComponent.string = i ? '----------Composite Mode----------' : '----------Single Mode----------';
            labelComponent.color = Color.WHITE;
            labelComponent.overflow = 0;
            this.labelComponentList[this.labelComponentList.length] = labelComponent;
          }

          y -= height; // single

          let currentRow = 0;

          for (let i = 0; i < this.strSingle.length; i++, currentRow++) {
            if (i === this.strSingle.length >> 1) {
              x += width;
              currentRow = 0;
            }

            const newNode = i ? instantiate(this.singleModeToggle) : this.singleModeToggle;
            newNode.setPosition(x, y - height * currentRow, 0.0);
            newNode.setScale(0.5, 0.5, 0.5);
            newNode.parent = this.singleModeToggle.parent;
            const textComponent = newNode.getComponentInChildren(RichText);
            textComponent.string = this.strSingle[i];
            this.textComponentList[this.textComponentList.length] = textComponent;
            this.textContentList[this.textContentList.length] = textComponent.string;
            newNode.on(Toggle.EventType.TOGGLE, this.toggleSingleMode, this);
            this.singleModeToggleList[i] = newNode;
          }

          x += width; // buttons

          this.EnableAllCompositeModeButton.setPosition(x + 15, y, 0.0);
          this.EnableAllCompositeModeButton.setScale(0.5, 0.5, 0.5);
          this.EnableAllCompositeModeButton.on(Button.EventType.CLICK, this.enableAllCompositeMode, this);
          this.EnableAllCompositeModeButton.parent = buttonNode;
          let labelComponent = this.EnableAllCompositeModeButton.getComponentInChildren(Label);
          this.labelComponentList[this.labelComponentList.length] = labelComponent;
          const changeColorButton = instantiate(this.EnableAllCompositeModeButton);
          changeColorButton.setPosition(x + 90, y, 0.0);
          changeColorButton.setScale(0.5, 0.5, 0.5);
          changeColorButton.on(Button.EventType.CLICK, this.changeTextColor, this);
          changeColorButton.parent = buttonNode;
          labelComponent = changeColorButton.getComponentInChildren(Label);
          labelComponent.string = 'TextColor';
          this.labelComponentList[this.labelComponentList.length] = labelComponent;
          const HideButton = instantiate(this.EnableAllCompositeModeButton);
          HideButton.setPosition(x + 200, y, 0.0);
          HideButton.setScale(0.5, 0.5, 0.5);
          HideButton.on(Button.EventType.CLICK, this.hideUI, this);
          HideButton.parent = this.node.parent;
          labelComponent = HideButton.getComponentInChildren(Label);
          labelComponent.string = 'Hide UI';
          this.labelComponentList[this.labelComponentList.length] = labelComponent;
          this.hideButtonLabel = labelComponent; // misc

          y -= 40;

          for (let i = 0; i < this.strMisc.length; i++) {
            const newNode = instantiate(this.compositeModeToggle);
            newNode.setPosition(x, y - height * i, 0.0);
            newNode.setScale(0.5, 0.5, 0.5);
            newNode.parent = miscNode;
            const textComponent = newNode.getComponentInChildren(RichText);
            textComponent.string = this.strMisc[i];
            this.textComponentList[this.textComponentList.length] = textComponent;
            this.textContentList[this.textContentList.length] = textComponent.string;
            const toggleComponent = newNode.getComponent(Toggle);
            toggleComponent.isChecked = i ? true : false;
            newNode.on(Toggle.EventType.TOGGLE, i ? this.toggleLightingWithAlbedo : this.toggleCSMColoration, this);
            this.miscModeToggleList[i] = newNode;
          } // composite


          y -= 150;

          for (let i = 0; i < this.strComposite.length; i++) {
            const newNode = i ? instantiate(this.compositeModeToggle) : this.compositeModeToggle;
            newNode.setPosition(x, y - height * i, 0.0);
            newNode.setScale(0.5, 0.5, 0.5);
            newNode.parent = this.compositeModeToggle.parent;
            const textComponent = newNode.getComponentInChildren(RichText);
            textComponent.string = this.strComposite[i];
            this.textComponentList[this.textComponentList.length] = textComponent;
            this.textContentList[this.textContentList.length] = textComponent.string;
            newNode.on(Toggle.EventType.TOGGLE, this.toggleCompositeMode, this);
            this.compositeModeToggleList[i] = newNode;
          }
        }

        isTextMatched(textUI, textDescription) {
          let tempText = new String(textUI);
          const findIndex = tempText.search('>');

          if (findIndex === -1) {
            return textUI === textDescription;
          } else {
            tempText = tempText.substr(findIndex + 1);
            tempText = tempText.substr(0, tempText.search('<'));
            return tempText === textDescription;
          }
        }

        toggleSingleMode(toggle) {
          const debugView = director.root.debugView;
          const textComponent = toggle.getComponentInChildren(RichText);

          for (let i = 0; i < this.strSingle.length; i++) {
            if (this.isTextMatched(textComponent.string, this.strSingle[i])) {
              debugView.singleMode = i;
            }
          }
        }

        toggleCompositeMode(toggle) {
          const debugView = director.root.debugView;
          const textComponent = toggle.getComponentInChildren(RichText);

          for (let i = 0; i < this.strComposite.length; i++) {
            if (this.isTextMatched(textComponent.string, this.strComposite[i])) {
              debugView.enableCompositeMode(i, toggle.isChecked);
            }
          }
        }

        toggleLightingWithAlbedo(toggle) {
          const debugView = director.root.debugView;
          debugView.lightingWithAlbedo = toggle.isChecked;
        }

        toggleCSMColoration(toggle) {
          const debugView = director.root.debugView;
          debugView.csmLayerColoration = toggle.isChecked;
        }

        enableAllCompositeMode(button) {
          const debugView = director.root.debugView;
          debugView.enableAllCompositeMode(true);

          for (let i = 0; i < this.compositeModeToggleList.length; i++) {
            const toggleComponent = this.compositeModeToggleList[i].getComponent(Toggle);
            toggleComponent.isChecked = true;
          }

          let toggleComponent = this.miscModeToggleList[0].getComponent(Toggle);
          toggleComponent.isChecked = false;
          debugView.csmLayerColoration = false;
          toggleComponent = this.miscModeToggleList[1].getComponent(Toggle);
          toggleComponent.isChecked = true;
          debugView.lightingWithAlbedo = true;
        }

        hideUI(button) {
          const titleNode = this.node.getChildByName('Titles');
          const activeValue = !titleNode.active;
          this.singleModeToggleList[0].parent.active = activeValue;
          this.miscModeToggleList[0].parent.active = activeValue;
          this.compositeModeToggleList[0].parent.active = activeValue;
          this.EnableAllCompositeModeButton.parent.active = activeValue;
          titleNode.active = activeValue;
          this.hideButtonLabel.string = activeValue ? 'Hide UI' : 'Show UI';
        }

        changeTextColor(button) {
          this._currentColorIndex++;

          if (this._currentColorIndex >= this.strColor.length) {
            this._currentColorIndex = 0;
          }

          for (let i = 0; i < this.textComponentList.length; i++) {
            this.textComponentList[i].string = this.strColor[this._currentColorIndex] + this.textContentList[i] + '</color>';
          }

          for (let i = 0; i < this.labelComponentList.length; i++) {
            this.labelComponentList[i].color = this.color[this._currentColorIndex];
          }
        }

        onLoad() {}

        update(deltaTime) {}

      }, (_descriptor$1 = _applyDecoratedDescriptor(_class2$1.prototype, "compositeModeToggle", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2$1.prototype, "singleModeToggle", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2$1.prototype, "EnableAllCompositeModeButton", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2$1)) || _class$2);

      cclegacy._RF.pop();
    }
  };
});

(function(r) {
  r('virtual:///prerequisite-imports/main', 'chunks:///main.js'); 
})(function(mid, cid) {
    System.register(mid, [cid], function (_export, _context) {
    return {
        setters: [function(_m) {
            var _exportObj = {};

            for (var _key in _m) {
              if (_key !== "default" && _key !== "__esModule") _exportObj[_key] = _m[_key];
            }
      
            _export(_exportObj);
        }],
        execute: function () { }
    };
    });
});