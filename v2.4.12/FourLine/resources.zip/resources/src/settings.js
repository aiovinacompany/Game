window._CCSettings = {
    platform: "ios",
    groupList: [
        "default"
    ],
    collisionMatrix: [
        [
            true
        ]
    ],
    hasResourcesBundle: false,
    hasStartSceneBundle: false,
    remoteBundles: [],
    subpackages: [],
    launchScene: "db://assets/LoadScene/LoadScene.fire",
    orientation: "",
    server: "",
    debug: true,
    jsList: []
};
