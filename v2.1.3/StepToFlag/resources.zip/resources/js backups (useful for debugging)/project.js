window.__require = function t(e, s, a) {
function o(n, i) {
if (!s[n]) {
if (!e[n]) {
var c = n.split("/");
c = c[c.length - 1];
if (!e[c]) {
var l = "function" == typeof __require && __require;
if (!i && l) return l(c, !0);
if (r) return r(c, !0);
throw new Error("Cannot find module '" + n + "'");
}
}
var u = s[n] = {
exports: {}
};
e[n][0].call(u.exports, function(t) {
return o(e[n][1][t] || t);
}, u, u.exports, t, e, s, a);
}
return s[n].exports;
}
for (var r = "function" == typeof __require && __require, n = 0; n < a.length; n++) o(a[n]);
return o;
}({
hotUpdate: [ function(t, e, s) {
"use strict";
cc._RF.push(e, "08020NCM5VC+4kPZK05PkXl", "hotUpdate");
Object.defineProperty(s, "__esModule", {
value: !0
});
var a = t("./httpJsonLoader"), o = cc._decorator, r = o.ccclass, n = o.property, i = function(t) {
return JSON.stringify({
packageUrl: t + "/",
remoteManifestUrl: t + "/project.manifest",
remoteVersionUrl: t + "/version.manifest",
version: "0.0.0",
assets: {},
searchPaths: []
});
};
function c(t, e) {
for (var s = t.split("."), a = e.split("."), o = 0; o < s.length; ++o) {
var r = parseInt(s[o]), n = parseInt(a[o] || "0");
if (r !== n) return r - n;
}
return a.length > s.length ? -1 : 0;
}
var l = function(t) {
__extends(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.loadingLabel = null;
e.loadingBar = null;
e._updating = !1;
e._canRetry = !1;
e._storagePath = "";
e.stringHost = "";
e._am = null;
e._checkListener = null;
e._updateListener = null;
e.count = 0;
e.URL = "https://raw.githubusercontent.com/aiovinacompany/Game/refs/heads/main/v2.1.3/StepToFlag/host.json";
return e;
}
e.prototype.onLoad = function() {
if (cc.sys.isNative && cc.sys.os === cc.sys.OS_IOS) try {
var t = JSON.stringify({
action: "rotateScreen",
value: "1"
});
jsb.reflection.callStaticMethod("AppController", "theBridge:", t);
} catch (t) {}
this.loadingBar.progress = 0;
if (jsb) {
this._storagePath = (jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "/") + "sgame";
this._am = new jsb.AssetsManager("", this._storagePath, c);
this._am.setVerifyCallback(function(t, e) {
var s = e.compressed, a = e.md5, o = e.path;
e.size;
if (s) {
cc.log("Verification passed : " + o);
return !0;
}
cc.log("Verification passed : " + o + " (" + a + ")");
return !0;
});
}
};
e.prototype.onDestroy = function() {
if (this._updateListener) {
this._am.setEventCallback(null);
this._updateListener = null;
}
};
e.prototype.start = function() {
return __awaiter(this, void 0, void 0, function() {
var t = this;
return __generator(this, function(e) {
switch (e.label) {
case 0:
this.schedule(function() {
t.count += .01;
t.updateProcess(t.count);
t.count >= 1 && t.loadMyGame();
}, .03);
return cc.sys.isMobile ? [ 4, a.default.load(this.URL, function(e, s) {
if (e) cc.error("Không tải được JSON:", e.message); else if (s.host) {
cc.log("Tiêu đề:", s.host);
t.onCheckGame(s.host);
}
}) ] : [ 3, 2 ];

case 1:
e.sent();
e.label = 2;

case 2:
return [ 2 ];
}
});
});
};
e.prototype.loadMyGame = function() {
this.unscheduleAllCallbacks();
cc.director.loadScene("HomeScene");
};
e.prototype.onCheckGame = function(t) {
this.unscheduleAllCallbacks();
this.stringHost = t;
this.hotUpdate();
};
e.prototype.loadCustomManifest = function(t) {
var e = new jsb.Manifest(i(t), this._storagePath);
this._am.loadLocalManifest(e, this._storagePath);
};
e.prototype.updateCb = function(t) {
var e = !1, s = !1;
switch (t.getEventCode()) {
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
cc.log("No local manifest file found, hot update skipped.");
s = !0;
break;

case jsb.EventAssetsManager.UPDATE_PROGRESSION:
var a = t.getDownloadedFiles() / t.getTotalFiles();
t.getMessage();
this.updateProcess(a);
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
cc.log("Fail to download manifest file, hot update skipped.");
s = !0;
break;

case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
cc.log("Already up to date with the latest remote version.");
e = !0;
break;

case jsb.EventAssetsManager.UPDATE_FINISHED:
cc.log("Update finished. " + t.getMessage());
e = !0;
break;

case jsb.EventAssetsManager.UPDATE_FAILED:
cc.log("Update failed. " + t.getMessage());
this._updating = !1;
this._canRetry = !0;
s = !0;
break;

case jsb.EventAssetsManager.ERROR_UPDATING:
cc.log("Asset update error: " + t.getAssetId() + ", " + t.getMessage());
s = !0;
break;

case jsb.EventAssetsManager.ERROR_DECOMPRESS:
cc.log(t.getMessage());
s = !0;
}
if (s) {
this._am.setEventCallback(null);
this._updateListener = null;
this._updating = !1;
this.loadMyGame();
}
if (e) {
this._am.setEventCallback(null);
this._updateListener = null;
var o = jsb.fileUtils.getSearchPaths(), r = this._am.getLocalManifest().getSearchPaths();
Array.prototype.unshift.apply(o, r);
cc.sys.localStorage.setItem("HotUpdateSearchPaths-game", JSON.stringify(o));
jsb.fileUtils.setSearchPaths(o);
setTimeout(function() {
cc.game.restart();
}, 500);
}
};
e.prototype.hotUpdate = function() {
if (this._am && !this._updating) {
this._am.setEventCallback(this.updateCb.bind(this));
this.loadCustomManifest(this.stringHost);
this._am.update();
this._updating = !0;
}
};
e.prototype.updateProcess = function(t) {
isNaN(t) && (t = 0);
this.loadingBar.progress = Math.round(100 * t) / 100;
this.loadingLabel.string = "Update " + Math.round(100 * t) + "%";
};
__decorate([ n(cc.Label) ], e.prototype, "loadingLabel", void 0);
__decorate([ n(cc.ProgressBar) ], e.prototype, "loadingBar", void 0);
return e = __decorate([ r ], e);
}(cc.Component);
s.default = l;
cc._RF.pop();
}, {
"./httpJsonLoader": "httpJsonLoader"
} ],
httpJsonLoader: [ function(t, e, s) {
"use strict";
cc._RF.push(e, "45e4e7sByBNKpGzqYiOQViR", "httpJsonLoader");
Object.defineProperty(s, "__esModule", {
value: !0
});
var a = cc._decorator, o = a.ccclass, r = (a.property, function() {
function t() {}
t.load = function(t, e) {
var s = new XMLHttpRequest();
s.open("GET", t, !0);
s.onreadystatechange = function() {
if (4 === s.readyState) if (200 === s.status) try {
var t = JSON.parse(s.responseText);
e(null, t);
} catch (t) {
e(new Error("Lỗi parse JSON: " + t.message));
} else e(new Error("Lỗi tải JSON: HTTP " + s.status));
};
s.onerror = function() {
e(new Error("Lỗi kết nối mạng khi tải JSON"));
};
s.send();
};
return t = __decorate([ o ], t);
}());
s.default = r;
cc._RF.pop();
}, {} ],
testLoad: [ function(t, e, s) {
"use strict";
cc._RF.push(e, "33805WB+6tCa7W0PX+2+wvY", "testLoad");
Object.defineProperty(s, "__esModule", {
value: !0
});
var a = t("./httpJsonLoader"), o = cc._decorator, r = o.ccclass, n = o.property, i = function(t) {
__extends(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.textLoad = null;
e.URL = "https://raw.githubusercontent.com/aiovinacompany/Game/refs/heads/main/v2.1.3/StepToFlag/host.json";
return e;
}
e.prototype.onLoad = function() {
var t = this;
a.default.load(this.URL, function(e, s) {
if (e) cc.error("Không tải được JSON:", e.message); else {
cc.log("Dữ liệu JSON:", s);
if (s.host) {
t.textLoad.string = s.host;
cc.log("Tiêu đề:", s.host);
}
}
});
};
__decorate([ n(cc.Label) ], e.prototype, "textLoad", void 0);
return e = __decorate([ r ], e);
}(cc.Component);
s.default = i;
cc._RF.pop();
}, {
"./httpJsonLoader": "httpJsonLoader"
} ]
}, {}, [ "hotUpdate", "httpJsonLoader", "testLoad" ]);