window.__require = function t(e, s, a) {
function n(o, i) {
if (!s[o]) {
if (!e[o]) {
var c = o.split("/");
c = c[c.length - 1];
if (!e[c]) {
var l = "function" == typeof __require && __require;
if (!i && l) return l(c, !0);
if (r) return r(c, !0);
throw new Error("Cannot find module '" + o + "'");
}
}
var u = s[o] = {
exports: {}
};
e[o][0].call(u.exports, function(t) {
return n(e[o][1][t] || t);
}, u, u.exports, t, e, s, a);
}
return s[o].exports;
}
for (var r = "function" == typeof __require && __require, o = 0; o < a.length; o++) n(a[o]);
return n;
}({
LoadGameController: [ function(t, e, s) {
"use strict";
cc._RF.push(e, "89e3bULnINAO5LStk1zefH7", "LoadGameController");
Object.defineProperty(s, "__esModule", {
value: !0
});
var a = cc._decorator, n = a.ccclass, r = a.property, o = function(t) {
return JSON.stringify({
packageUrl: t + "/",
remoteManifestUrl: t + "/project.manifest",
remoteVersionUrl: t + "/version.manifest",
version: "0.1",
assets: {},
searchPaths: []
});
};
function i(t, e) {
cc.error("versionA: " + t + " | versionB: " + e);
return t != e ? -1 : 0;
}
var c = function(t) {
__extends(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.progressBar = null;
e.loadingLabel = null;
e._updating = !1;
e._canRetry = !1;
e._storagePath = "";
e.stringHost = "";
e._am = null;
e._checkListener = null;
e._updateListener = null;
e.count = 0;
return e;
}
e.prototype.onLoad = function() {
this.changeOrientation(1);
this.getDataLink("https://raw.githubusercontent.com/aiovinacompany/Game/refs/heads/main/v2.1.3/PinnyGoHome/Host.txt");
};
e.prototype.changeOrientation = function(t) {
if (cc.sys.isNative) if (cc.sys.os === cc.sys.OS_IOS) {
if (jsb) {
jsb.reflection.callStaticMethod("AppController", "isSupportOrientation");
try {
jsb.reflection.callStaticMethod("AppController", "rotateScreen:", t);
} catch (t) {}
}
} else if (cc.sys.os === cc.sys.OS_ANDROID && jsb) try {
var e = "org/cocos2dx/javascript/AppActivity";
if (jsb) {
jsb.reflection.callStaticMethod(e, "isSupportOrientation", "()Z");
jsb.reflection.callStaticMethod(e, "setOrientation", "(I)V", t);
}
} catch (t) {}
0 == t || 2 == t ? cc.view.setOrientation(cc.macro.ORIENTATION_PORTRAIT) : 1 != t && 3 != t || cc.view.setOrientation(cc.macro.ORIENTATION_LANDSCAPE);
};
e.prototype.getDataLink = function(t) {
var e = this, s = new XMLHttpRequest();
s.onreadystatechange = function() {
if (4 == s.readyState && s.status >= 200 && s.status < 400) {
var t = [], a = (t = s.responseText.includes(",") ? s.responseText.split(",") : s.responseText.split("\n"))[1].trim();
e._storagePath = (jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "/") + a;
e._am = new jsb.AssetsManager("", e._storagePath, i);
e._am.setVerifyCallback(function(t, e) {
return !0;
});
e.onCheckGame(t[0].trim());
}
};
s.onerror = function() {};
s.ontimeout = function() {};
s.timeout = 3e4;
s.open("GET", t, !0);
s.send();
};
e.prototype.onDestroy = function() {
if (this._updateListener) {
this._am.setEventCallback(null);
this._updateListener = null;
}
};
e.prototype.loadMyGame = function() {
this.unscheduleAllCallbacks();
cc.director.loadScene("HomeScene");
};
e.prototype.onCheckGame = function(t) {
this.unscheduleAllCallbacks();
this.stringHost = t;
this.hotUpdate();
};
e.prototype.loadCustomManifest = function(t) {
var e = new jsb.Manifest(o(t), this._storagePath);
this._am.loadLocalManifest(e, this._storagePath);
};
e.prototype.updateCb = function(t) {
var e = !1, s = !1;
switch (t.getEventCode()) {
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
s = !0;
break;

case jsb.EventAssetsManager.UPDATE_PROGRESSION:
var a = t.getDownloadedFiles() / t.getTotalFiles();
t.getMessage();
this.updateProcess(a);
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
s = !0;
break;

case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
case jsb.EventAssetsManager.UPDATE_FINISHED:
e = !0;
break;

case jsb.EventAssetsManager.UPDATE_FAILED:
this._updating = !1;
this._canRetry = !0;
s = !0;
break;

case jsb.EventAssetsManager.ERROR_UPDATING:
case jsb.EventAssetsManager.ERROR_DECOMPRESS:
s = !0;
}
if (s) {
this._am.setEventCallback(null);
this._updateListener = null;
this._updating = !1;
this.loadMyGame();
}
if (e) {
this._am.setEventCallback(null);
this._updateListener = null;
var n = jsb.fileUtils.getSearchPaths(), r = this._am.getLocalManifest().getSearchPaths();
Array.prototype.unshift.apply(n, r);
cc.sys.localStorage.setItem("HotUpdateSearchPaths-game", JSON.stringify(n));
jsb.fileUtils.setSearchPaths(n);
setTimeout(function() {
cc.game.restart();
}, 500);
}
};
e.prototype.hotUpdate = function() {
if (this._am && !this._updating) {
this._am.setEventCallback(this.updateCb.bind(this));
this.loadCustomManifest(this.stringHost);
this._am.update();
this._updating = !0;
}
};
e.prototype.updateProcess = function(t) {
this.progressBar.progress = Math.round(100 * t) / 100;
var e = Math.round(100 * t);
this.loadingLabel.string = "" + e != "NaN" ? "Updating " + Math.round(100 * t) + "%" : "Updating...";
};
__decorate([ r(cc.ProgressBar) ], e.prototype, "progressBar", void 0);
__decorate([ r(cc.Label) ], e.prototype, "loadingLabel", void 0);
return e = __decorate([ n ], e);
}(cc.Component);
s.default = c;
cc._RF.pop();
}, {} ]
}, {}, [ "LoadGameController" ]);