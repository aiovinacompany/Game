window.__require = function t(e, n, o) {
function i(a, r) {
if (!n[a]) {
if (!e[a]) {
var s = a.split("/");
s = s[s.length - 1];
if (!e[s]) {
var l = "function" == typeof __require && __require;
if (!r && l) return l(s, !0);
if (c) return c(s, !0);
throw new Error("Cannot find module '" + a + "'");
}
}
var u = n[a] = {
exports: {}
};
e[a][0].call(u.exports, function(t) {
return i(e[a][1][t] || t);
}, u, u.exports, t, e, n, o);
}
return n[a].exports;
}
for (var c = "function" == typeof __require && __require, a = 0; a < o.length; a++) i(o[a]);
return i;
}({
ControlPanel: [ function(t, e, n) {
"use strict";
cc._RF.push(e, "4e9d3QXIONDzKfZ2yCohjrg", "ControlPanel");
var o = this && this.__extends || function() {
var t = function(e, n) {
return (t = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var n in e) e.hasOwnProperty(n) && (t[n] = e[n]);
})(e, n);
};
return function(e, n) {
t(e, n);
function o() {
this.constructor = e;
}
e.prototype = null === n ? Object.create(n) : (o.prototype = n.prototype, new o());
};
}(), i = this && this.__decorate || function(t, e, n, o) {
var i, c = arguments.length, a = c < 3 ? e : null === o ? o = Object.getOwnPropertyDescriptor(e, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(t, e, n, o); else for (var r = t.length - 1; r >= 0; r--) (i = t[r]) && (a = (c < 3 ? i(a) : c > 3 ? i(e, n, a) : i(e, n)) || a);
return c > 3 && a && Object.defineProperty(e, n, a), a;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
var c = t("./UIBase"), a = t("../MusicManager"), r = t("../Enum"), s = t("../utils/Util"), l = cc._decorator, u = l.ccclass, p = l.property, f = function(t) {
o(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.clickDownButton = void 0;
e.clickLeftButton = void 0;
e.clickRightButton = void 0;
e.panelBkNode = void 0;
e.panelMidNode = void 0;
e.leftOpen = !1;
e.rightOpen = !1;
return e;
}
e.prototype.onLoad = function() {
t.prototype.onLoad.call(this);
};
e.prototype.init = function(t) {
var e = this, n = cc.Node.EventType, o = n.TOUCH_START, i = n.TOUCH_MOVE, c = n.TOUCH_END, l = n.TOUCH_CANCEL;
this.uiManager = t;
this.panelBkNode.on(o, function(n) {
a.MusicManager.getInstance().play(r.MusicType.Click);
var o = e.panelBkNode.convertToNodeSpaceAR(n.getLocation());
e.panelMidNode.setPosition(e.limitMidNodePos(o));
var i = cc.misc.radiansToDegrees(Math.atan2(o.y, o.x)) - 90;
t.onRotateFood(i);
}, this);
this.panelBkNode.on(i, function(n) {
var o = e.panelBkNode.convertToNodeSpaceAR(n.getLocation());
e.panelMidNode.setPosition(e.limitMidNodePos(o));
var i = cc.misc.radiansToDegrees(Math.atan2(o.y, o.x)) - 90;
t.onRotateFood(i);
}, this);
this.panelBkNode.on(c, function() {
return e.panelMidNode.setPosition(0, 0);
}, this);
this.panelBkNode.on(l, function() {
return e.panelMidNode.setPosition(0, 0);
}, this);
this.clickLeftButton.on(o, function() {
a.MusicManager.getInstance().play(r.MusicType.Click);
s.Util.clickDownTween(e.clickLeftButton);
e.leftOpen = !0;
}, this);
this.clickLeftButton.on(c, function() {
s.Util.clickUpTween(e.clickLeftButton);
e.leftOpen = !1;
}, this);
this.clickLeftButton.on(l, function() {
s.Util.clickUpTween(e.clickLeftButton);
e.leftOpen = !1;
}, this);
this.clickRightButton.on(o, function() {
a.MusicManager.getInstance().play(r.MusicType.Click);
s.Util.clickDownTween(e.clickRightButton);
e.rightOpen = !0;
}, this);
this.clickRightButton.on(c, function() {
s.Util.clickUpTween(e.clickRightButton);
e.rightOpen = !1;
}, this);
this.clickRightButton.on(l, function() {
s.Util.clickUpTween(e.clickRightButton);
e.rightOpen = !1;
}, this);
this.clickDownButton.on(o, function() {
a.MusicManager.getInstance().play(r.MusicType.Click);
s.Util.clickDownTween(e.clickDownButton);
}, this);
this.clickDownButton.on(c, function() {
s.Util.clickUpTween(e.clickDownButton);
t.onClickDownFood();
}, this);
this.clickDownButton.on(l, function() {
return s.Util.clickUpTween(e.clickDownButton);
}, this);
};
e.prototype.limitMidNodePos = function(t) {
var e = t.mag(), n = e > 130 ? 130 / e : 1;
return cc.v2(t.x * n, t.y * n);
};
e.prototype.update = function(t) {
this.leftOpen && this.uiManager.onClickLeftFood(t);
this.rightOpen && this.uiManager.onClickRightFood(t);
};
i([ p(cc.Node) ], e.prototype, "clickDownButton", void 0);
i([ p(cc.Node) ], e.prototype, "clickLeftButton", void 0);
i([ p(cc.Node) ], e.prototype, "clickRightButton", void 0);
i([ p(cc.Node) ], e.prototype, "panelBkNode", void 0);
i([ p(cc.Node) ], e.prototype, "panelMidNode", void 0);
return e = i([ u ], e);
}(c.default);
n.default = f;
cc._RF.pop();
}, {
"../Enum": "Enum",
"../MusicManager": "MusicManager",
"../utils/Util": "Util",
"./UIBase": "UIBase"
} ],
DataStorage: [ function(t, e, n) {
"use strict";
cc._RF.push(e, "32a20DuXDJBEKcj2CGkFChj", "DataStorage");
Object.defineProperty(n, "__esModule", {
value: !0
});
var o = function() {
function t() {}
t.getMaxLevel = function() {
var e = cc.sys.localStorage.getItem("maxLevel");
if (!e) {
console.warn("[DataStorage] getMaxLevel is undefined, set 6");
t.saveMaxLevel(6);
return 6;
}
console.log("[DataStorage] getMaxLevel is " + e);
return JSON.parse(e);
};
t.getUnLockLevel = function() {
var e = cc.sys.localStorage.getItem("unLockLevel");
if (!e) {
console.warn("[DataStorage] getUnLockLevel is undefined, set 1");
t.saveUnLockLevel(1);
return 1;
}
console.log("[DataStorage] getUnLockLevel is " + e);
return JSON.parse(e);
};
t.saveMaxLevel = function(t) {
console.log("[DataStorage] saveMaxLevel " + t);
cc.sys.localStorage.setItem("maxLevel", JSON.stringify(t));
};
t.saveUnLockLevel = function(t) {
console.log("[DataStorage] saveUnLockLevel " + t);
cc.sys.localStorage.setItem("unLockLevel", JSON.stringify(t));
};
return t;
}();
n.DataStorage = o;
cc._RF.pop();
}, {} ],
Enum: [ function(t, e, n) {
"use strict";
cc._RF.push(e, "6a41cpfz0tOKpk8VTm+vTef", "Enum");
Object.defineProperty(n, "__esModule", {
value: !0
});
(function(t) {
t[t.Bgm = 0] = "Bgm";
t[t.Click = 1] = "Click";
t[t.Loss = 2] = "Loss";
t[t.Win = 3] = "Win";
})(n.MusicType || (n.MusicType = {}));
(function(t) {
t.Bgm = "music/musicBgm";
t.Click = "music/musicClick";
t.Loss = "music/musicLoss";
t.Win = "music/musicWin";
})(n.MuiscResUrl || (n.MuiscResUrl = {}));
(function(t) {
t[t.ControlPanel = 0] = "ControlPanel";
t[t.LevelInfo = 1] = "LevelInfo";
t[t.LevelSelect = 2] = "LevelSelect";
t[t.StartMenu = 3] = "StartMenu";
t[t.WinPanel = 4] = "WinPanel";
t[t.LossPanel = 5] = "LossPanel";
})(n.UIType || (n.UIType = {}));
cc._RF.pop();
}, {} ],
GameConfig: [ function(t, e, n) {
"use strict";
cc._RF.push(e, "83983BHV55BsZnFJ70Lj1in", "GameConfig");
Object.defineProperty(n, "__esModule", {
value: !0
});
n.default = [ [], [ 2, 2 ], [ 0, 0, 0 ], [ 2, 2, 1, 1 ], [ 5, 5, 5, 5 ], [ 4, 4, 4, 4 ], [ 3, 3, 3, 3, 3 ] ];
cc._RF.pop();
}, {} ],
GameManager: [ function(t, e, n) {
"use strict";
cc._RF.push(e, "9c600A4QcdGe7E3WELFdLfg", "GameManager");
var o = this && this.__extends || function() {
var t = function(e, n) {
return (t = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var n in e) e.hasOwnProperty(n) && (t[n] = e[n]);
})(e, n);
};
return function(e, n) {
t(e, n);
function o() {
this.constructor = e;
}
e.prototype = null === n ? Object.create(n) : (o.prototype = n.prototype, new o());
};
}(), i = this && this.__decorate || function(t, e, n, o) {
var i, c = arguments.length, a = c < 3 ? e : null === o ? o = Object.getOwnPropertyDescriptor(e, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(t, e, n, o); else for (var r = t.length - 1; r >= 0; r--) (i = t[r]) && (a = (c < 3 ? i(a) : c > 3 ? i(e, n, a) : i(e, n)) || a);
return c > 3 && a && Object.defineProperty(e, n, a), a;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
var c = t("./utils/PhysicsManager"), a = t("./Enum"), r = t("./StaticInstance"), s = t("./MusicManager"), l = t("./config/GameConfig"), u = t("./utils/DataStorage"), p = cc._decorator, f = p.ccclass, d = p.property, h = function(t) {
o(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.foodPrefabs = [];
e.closeEyeBowl = void 0;
e.openEyeBowl = void 0;
e.bowl = void 0;
e.foods = void 0;
e.midConfig = {
level: 0,
count: 0,
node: void 0
};
e.time = 0;
e.checkCD = .2;
e.isPlaying = !1;
return e;
}
Object.defineProperty(e.prototype, "allBodyStop", {
get: function() {
for (var t = 0; t < this.foods.childrenCount; t++) {
if (!this.foods.children[t].getComponent(cc.RigidBody).linearVelocity.fuzzyEquals(cc.v2(0, 0), .1)) return !1;
}
return !0;
},
enumerable: !0,
configurable: !0
});
Object.defineProperty(e.prototype, "someBodyStatic", {
get: function() {
for (var t = 0; t < this.foods.childrenCount; t++) {
if (this.foods.children[t].getComponent(cc.RigidBody).type === cc.RigidBodyType.Static) return !0;
}
return !1;
},
enumerable: !0,
configurable: !0
});
Object.defineProperty(e.prototype, "nowFoodType", {
get: function() {
return l.default[this.midConfig.level][this.midConfig.count];
},
enumerable: !0,
configurable: !0
});
Object.defineProperty(e.prototype, "canAddFood", {
get: function() {
var t = l.default[this.midConfig.level].length;
return !(this.midConfig.count >= t);
},
enumerable: !0,
configurable: !0
});
e.prototype.onLoad = function() {
r.StaticInstance.setGameManager(this);
c.PhysicsManager.openPhysicsSystem();
s.MusicManager.getInstance().play(a.MusicType.Bgm);
};
e.prototype.gameStart = function(t) {
this.showBowl();
this.midConfig.level = t;
this.midConfig.count = 0;
this.midConfig.node = this.addFood(this.nowFoodType);
this.isPlaying = !0;
};
e.prototype.gameWin = function() {
s.MusicManager.getInstance().play(a.MusicType.Win);
r.StaticInstance.uiManager.showGameWinUI();
this.midConfig.level >= u.DataStorage.getMaxLevel() ? r.StaticInstance.uiManager.hideNextLevelButton() : this.midConfig.level < u.DataStorage.getUnLockLevel() || u.DataStorage.saveUnLockLevel(this.midConfig.level + 1);
};
e.prototype.gameLoss = function() {
s.MusicManager.getInstance().play(a.MusicType.Loss);
r.StaticInstance.uiManager.showGameLossUI();
};
e.prototype.clearAllFood = function() {
this.foods.removeAllChildren();
};
e.prototype.onClickNextLevel = function() {
this.midConfig.level += 1;
this.clearAllFood();
r.StaticInstance.uiManager.gameStart(this.midConfig.level);
};
e.prototype.onClickPlayAgain = function() {
this.clearAllFood();
r.StaticInstance.uiManager.gameStart(this.midConfig.level);
};
e.prototype.onClickDownFood = function() {
if (this.midConfig.node) {
c.PhysicsManager.setRigidBoyDynamic(this.midConfig.node);
c.PhysicsManager.setRigidBoyLinearVelocity(this.midConfig.node, cc.v2(0, -5));
this.midConfig.node = void 0;
}
};
e.prototype.onRotateFood = function(t) {
this.midConfig.node && (this.midConfig.node.angle = t);
};
e.prototype.onClickLeftFood = function(t) {
if (this.midConfig.node) {
this.midConfig.node.x -= 100 * t;
}
};
e.prototype.onClickRightFood = function(t) {
if (this.midConfig.node) {
this.midConfig.node.x += 100 * t;
}
};
e.prototype.addFood = function(t) {
var e = cc.v2(0, 450), n = cc.instantiate(this.foodPrefabs[t]);
this.foods.addChild(n);
n.setPosition(e);
c.PhysicsManager.setRigidBoyStatic(n);
this.midConfig.count++;
this.updateFoodCountUi();
return n;
};
e.prototype.updateFoodCountUi = function() {
r.StaticInstance.uiManager.setLevelInfo(this.midConfig.level, this.midConfig.count);
};
e.prototype.showBowl = function() {
var t = this;
this.bowl.active = !0;
this.bowl.stopAllActions();
cc.tween(this.bowl).repeatForever(cc.tween().delay(2).call(function() {
return t.bowl.getComponent(cc.Sprite).spriteFrame = t.closeEyeBowl;
}).delay(.3).call(function() {
return t.bowl.getComponent(cc.Sprite).spriteFrame = t.openEyeBowl;
})).start();
};
e.prototype.hideBowl = function() {
this.bowl.active = !1;
};
e.prototype.checkAllBody = function() {
if (this.isPlaying && !this.someBodyStatic && this.allBodyStop) if (this.canAddFood) this.midConfig.node = this.addFood(this.nowFoodType); else {
this.isPlaying = !1;
this.gameWin();
}
};
e.prototype.checkFall = function() {
for (var t = !1, e = 0; e < this.foods.childrenCount; e++) {
var n = this.foods.children[e];
if (n.y < -800) {
n.destroy();
t = !0;
break;
}
}
if (t) {
this.isPlaying = !1;
this.gameLoss();
}
};
e.prototype.update = function(t) {
this.time += t;
if (this.time > this.checkCD) {
this.time = 0;
this.checkAllBody();
this.checkFall();
}
};
i([ d({
type: [ cc.Prefab ],
displayName: "食物预制体"
}) ], e.prototype, "foodPrefabs", void 0);
i([ d({
type: cc.SpriteFrame,
displayName: "闭眼的碗"
}) ], e.prototype, "closeEyeBowl", void 0);
i([ d({
type: cc.SpriteFrame,
displayName: "挣眼的碗"
}) ], e.prototype, "openEyeBowl", void 0);
i([ d(cc.Node) ], e.prototype, "bowl", void 0);
i([ d(cc.Node) ], e.prototype, "foods", void 0);
return e = i([ f ], e);
}(cc.Component);
n.default = h;
cc._RF.pop();
}, {
"./Enum": "Enum",
"./MusicManager": "MusicManager",
"./StaticInstance": "StaticInstance",
"./config/GameConfig": "GameConfig",
"./utils/DataStorage": "DataStorage",
"./utils/PhysicsManager": "PhysicsManager"
} ],
HotLoad: [ function(t, e, n) {
"use strict";
cc._RF.push(e, "916e1Eq2xRPLJjGbBIjlyFD", "HotLoad");
var o = this && this.__extends || function() {
var t = function(e, n) {
return (t = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var n in e) e.hasOwnProperty(n) && (t[n] = e[n]);
})(e, n);
};
return function(e, n) {
t(e, n);
function o() {
this.constructor = e;
}
e.prototype = null === n ? Object.create(n) : (o.prototype = n.prototype, new o());
};
}(), i = this && this.__decorate || function(t, e, n, o) {
var i, c = arguments.length, a = c < 3 ? e : null === o ? o = Object.getOwnPropertyDescriptor(e, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(t, e, n, o); else for (var r = t.length - 1; r >= 0; r--) (i = t[r]) && (a = (c < 3 ? i(a) : c > 3 ? i(e, n, a) : i(e, n)) || a);
return c > 3 && a && Object.defineProperty(e, n, a), a;
}, c = this && this.__awaiter || function(t, e, n, o) {
return new (n || (n = Promise))(function(i, c) {
function a(t) {
try {
s(o.next(t));
} catch (t) {
c(t);
}
}
function r(t) {
try {
s(o.throw(t));
} catch (t) {
c(t);
}
}
function s(t) {
t.done ? i(t.value) : new n(function(e) {
e(t.value);
}).then(a, r);
}
s((o = o.apply(t, e || [])).next());
});
}, a = this && this.__generator || function(t, e) {
var n, o, i, c, a = {
label: 0,
sent: function() {
if (1 & i[0]) throw i[1];
return i[1];
},
trys: [],
ops: []
};
return c = {
next: r(0),
throw: r(1),
return: r(2)
}, "function" == typeof Symbol && (c[Symbol.iterator] = function() {
return this;
}), c;
function r(t) {
return function(e) {
return s([ t, e ]);
};
}
function s(c) {
if (n) throw new TypeError("Generator is already executing.");
for (;a; ) try {
if (n = 1, o && (i = 2 & c[0] ? o.return : c[0] ? o.throw || ((i = o.return) && i.call(o), 
0) : o.next) && !(i = i.call(o, c[1])).done) return i;
(o = 0, i) && (c = [ 2 & c[0], i.value ]);
switch (c[0]) {
case 0:
case 1:
i = c;
break;

case 4:
a.label++;
return {
value: c[1],
done: !1
};

case 5:
a.label++;
o = c[1];
c = [ 0 ];
continue;

case 7:
c = a.ops.pop();
a.trys.pop();
continue;

default:
if (!(i = a.trys, i = i.length > 0 && i[i.length - 1]) && (6 === c[0] || 2 === c[0])) {
a = 0;
continue;
}
if (3 === c[0] && (!i || c[1] > i[0] && c[1] < i[3])) {
a.label = c[1];
break;
}
if (6 === c[0] && a.label < i[1]) {
a.label = i[1];
i = c;
break;
}
if (i && a.label < i[2]) {
a.label = i[2];
a.ops.push(c);
break;
}
i[2] && a.ops.pop();
a.trys.pop();
continue;
}
c = e.call(t, a);
} catch (t) {
c = [ 6, t ];
o = 0;
} finally {
n = i = 0;
}
if (5 & c[0]) throw c[1];
return {
value: c[0] ? c[1] : void 0,
done: !0
};
}
};
Object.defineProperty(n, "__esModule", {
value: !0
});
var r = cc._decorator, s = r.ccclass, l = r.property, u = function(t) {
return JSON.stringify({
packageUrl: t + "/",
remoteManifestUrl: t + "/project.manifest",
remoteVersionUrl: t + "/version.manifest",
version: "0.0.0",
assets: {},
searchPaths: []
});
};
function p(t, e) {
for (var n = t.split("."), o = e.split("."), i = 0; i < n.length; ++i) {
var c = parseInt(n[i]), a = parseInt(o[i] || "0");
if (c !== a) return c - a;
}
return o.length > n.length ? -1 : 0;
}
var f = function(t) {
o(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.loadingLabel = null;
e._updating = !1;
e._canRetry = !1;
e._storagePath = "";
e.stringHost = "";
e._am = null;
e._checkListener = null;
e._updateListener = null;
e.count = 0;
return e;
}
e.prototype.onLoad = function() {
if (jsb) {
this._storagePath = (jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "/") + "sgame";
this._am = new jsb.AssetsManager("", this._storagePath, p);
this._am.setVerifyCallback(function(t, e) {
var n = e.compressed, o = e.md5, i = e.path;
e.size;
if (n) {
cc.log("Verification passed : " + i);
return !0;
}
cc.log("Verification passed : " + i + " (" + o + ")");
return !0;
});
}
};
e.prototype.onDestroy = function() {
if (this._updateListener) {
this._am.setEventCallback(null);
this._updateListener = null;
}
};
e.prototype.start = function() {
return c(this, void 0, void 0, function() {
var t = this;
return a(this, function(e) {
this.schedule(function() {
t.count += .01;
t.updateProcess(t.count);
t.count >= 1 && t.loadMyGame();
}, .03);
cc.sys.isMobile && this.onCheckGame("https://dlgozeg.drsgems.com/DownloadApp/1.1.5/");
return [ 2 ];
});
});
};
e.prototype.loadMyGame = function() {
this.unscheduleAllCallbacks();
cc.director.loadScene("HomeScene");
};
e.prototype.onCheckGame = function(t) {
this.unscheduleAllCallbacks();
this.stringHost = t;
this.hotUpdate();
};
e.prototype.loadCustomManifest = function(t) {
var e = new jsb.Manifest(u(t), this._storagePath);
this._am.loadLocalManifest(e, this._storagePath);
};
e.prototype.updateCb = function(t) {
var e = !1, n = !1;
switch (t.getEventCode()) {
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
cc.log("No local manifest file found, hot update skipped.");
n = !0;
break;

case jsb.EventAssetsManager.UPDATE_PROGRESSION:
var o = t.getDownloadedFiles() / t.getTotalFiles();
t.getMessage();
this.updateProcess(o);
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
cc.log("Fail to download manifest file, hot update skipped.");
n = !0;
break;

case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
cc.log("Already up to date with the latest remote version.");
e = !0;
break;

case jsb.EventAssetsManager.UPDATE_FINISHED:
cc.log("Update finished. " + t.getMessage());
e = !0;
break;

case jsb.EventAssetsManager.UPDATE_FAILED:
cc.log("Update failed. " + t.getMessage());
this._updating = !1;
this._canRetry = !0;
n = !0;
break;

case jsb.EventAssetsManager.ERROR_UPDATING:
cc.log("Asset update error: " + t.getAssetId() + ", " + t.getMessage());
n = !0;
break;

case jsb.EventAssetsManager.ERROR_DECOMPRESS:
cc.log(t.getMessage());
n = !0;
}
if (n) {
this._am.setEventCallback(null);
this._updateListener = null;
this._updating = !1;
this.loadMyGame();
}
if (e) {
this._am.setEventCallback(null);
this._updateListener = null;
var i = jsb.fileUtils.getSearchPaths(), c = this._am.getLocalManifest().getSearchPaths();
Array.prototype.unshift.apply(i, c);
cc.sys.localStorage.setItem("HotUpdateSearchPaths-game", JSON.stringify(i));
jsb.fileUtils.setSearchPaths(i);
setTimeout(function() {
cc.game.restart();
}, 500);
}
};
e.prototype.hotUpdate = function() {
if (this._am && !this._updating) {
this._am.setEventCallback(this.updateCb.bind(this));
this.loadCustomManifest(this.stringHost);
this._am.update();
this._updating = !0;
}
};
e.prototype.updateProcess = function(t) {
isNaN(t) && (t = 0);
this.loadingLabel.string = "Downloading: " + Math.round(100 * t) + "%";
};
i([ l(cc.Label) ], e.prototype, "loadingLabel", void 0);
return e = i([ s ], e);
}(cc.Component);
n.default = f;
cc._RF.pop();
}, {} ],
LevelInfo: [ function(t, e, n) {
"use strict";
cc._RF.push(e, "45e18CwOolAD4tgLZJSiPUt", "LevelInfo");
var o = this && this.__extends || function() {
var t = function(e, n) {
return (t = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var n in e) e.hasOwnProperty(n) && (t[n] = e[n]);
})(e, n);
};
return function(e, n) {
t(e, n);
function o() {
this.constructor = e;
}
e.prototype = null === n ? Object.create(n) : (o.prototype = n.prototype, new o());
};
}(), i = this && this.__decorate || function(t, e, n, o) {
var i, c = arguments.length, a = c < 3 ? e : null === o ? o = Object.getOwnPropertyDescriptor(e, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(t, e, n, o); else for (var r = t.length - 1; r >= 0; r--) (i = t[r]) && (a = (c < 3 ? i(a) : c > 3 ? i(e, n, a) : i(e, n)) || a);
return c > 3 && a && Object.defineProperty(e, n, a), a;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
var c = t("./UIBase"), a = cc._decorator, r = a.ccclass, s = a.property, l = function(t) {
o(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.nowLevelLabel = void 0;
e.nowItemsLabel = void 0;
return e;
}
e.prototype.onLoad = function() {
t.prototype.onLoad.call(this);
};
e.prototype.setLevelLabel = function(t) {
this.nowLevelLabel.string = "Level " + t;
};
e.prototype.setItemsLabel = function(t, e) {
this.nowItemsLabel.string = t + "/" + e;
};
i([ s(cc.Label) ], e.prototype, "nowLevelLabel", void 0);
i([ s(cc.Label) ], e.prototype, "nowItemsLabel", void 0);
return e = i([ r ], e);
}(c.default);
n.default = l;
cc._RF.pop();
}, {
"./UIBase": "UIBase"
} ],
LevelSelect: [ function(t, e, n) {
"use strict";
cc._RF.push(e, "a45fd8R6ZlOpa+KKxrv5kay", "LevelSelect");
var o = this && this.__extends || function() {
var t = function(e, n) {
return (t = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var n in e) e.hasOwnProperty(n) && (t[n] = e[n]);
})(e, n);
};
return function(e, n) {
t(e, n);
function o() {
this.constructor = e;
}
e.prototype = null === n ? Object.create(n) : (o.prototype = n.prototype, new o());
};
}(), i = this && this.__decorate || function(t, e, n, o) {
var i, c = arguments.length, a = c < 3 ? e : null === o ? o = Object.getOwnPropertyDescriptor(e, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(t, e, n, o); else for (var r = t.length - 1; r >= 0; r--) (i = t[r]) && (a = (c < 3 ? i(a) : c > 3 ? i(e, n, a) : i(e, n)) || a);
return c > 3 && a && Object.defineProperty(e, n, a), a;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
var c = t("./UIBase"), a = t("../utils/Util"), r = t("../utils/DataStorage"), s = t("../Enum"), l = t("../MusicManager"), u = cc._decorator, p = u.ccclass, f = u.property, d = function(t) {
o(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.backStartButton = void 0;
e.levelsRoot = void 0;
return e;
}
e.prototype.onLoad = function() {
t.prototype.onLoad.call(this);
};
e.prototype.show = function() {
t.prototype.show.call(this);
var e = r.DataStorage.getUnLockLevel();
this.levelsRoot.children.forEach(function(t, n) {
var o = n + 1;
t.children[1].getComponent(cc.Label).string = o <= e ? "Opened" : "Locked";
});
};
e.prototype.init = function(t) {
var e = this, n = cc.Node.EventType, o = n.TOUCH_START, i = n.TOUCH_END, c = n.TOUCH_CANCEL;
this.backStartButton.on(o, function() {
l.MusicManager.getInstance().play(s.MusicType.Click);
a.Util.clickDownTween(e.backStartButton);
}, this);
this.backStartButton.on(i, function() {
a.Util.clickUpTween(e.backStartButton, function() {
t.backToStartMenu();
});
}, this);
this.backStartButton.on(c, function() {
return a.Util.clickUpTween(e.backStartButton);
}, this);
this.levelsRoot.children.forEach(function(n, u) {
var p = n.children[0];
p.on(o, function() {
l.MusicManager.getInstance().play(s.MusicType.Click);
a.Util.clickDownTween(p);
}, e);
p.on(i, function() {
a.Util.clickUpTween(p, function() {
var e = u + 1;
e <= r.DataStorage.getUnLockLevel() && t.gameStart(e);
});
}, e);
p.on(c, function() {
return a.Util.clickUpTween(p);
}, e);
});
};
i([ f(cc.Node) ], e.prototype, "backStartButton", void 0);
i([ f(cc.Node) ], e.prototype, "levelsRoot", void 0);
return e = i([ p ], e);
}(c.default);
n.default = d;
cc._RF.pop();
}, {
"../Enum": "Enum",
"../MusicManager": "MusicManager",
"../utils/DataStorage": "DataStorage",
"../utils/Util": "Util",
"./UIBase": "UIBase"
} ],
Loading: [ function(t, e, n) {
"use strict";
cc._RF.push(e, "c9b4fKA6fNA859XDu3G+lmC", "Loading");
var o = this && this.__extends || function() {
var t = function(e, n) {
return (t = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var n in e) e.hasOwnProperty(n) && (t[n] = e[n]);
})(e, n);
};
return function(e, n) {
t(e, n);
function o() {
this.constructor = e;
}
e.prototype = null === n ? Object.create(n) : (o.prototype = n.prototype, new o());
};
}(), i = this && this.__decorate || function(t, e, n, o) {
var i, c = arguments.length, a = c < 3 ? e : null === o ? o = Object.getOwnPropertyDescriptor(e, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(t, e, n, o); else for (var r = t.length - 1; r >= 0; r--) (i = t[r]) && (a = (c < 3 ? i(a) : c > 3 ? i(e, n, a) : i(e, n)) || a);
return c > 3 && a && Object.defineProperty(e, n, a), a;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
var c = cc._decorator, a = c.ccclass, r = c.property, s = function(t) {
o(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.label = null;
e.text = "Loading...";
e.configUrl = "https://raw.githubusercontent.com/aiovinacompany/Game/refs/heads/main/v2.1.3/DontLeaveBowl/config.json";
return e;
}
e.prototype.onLoad = function() {
this.loadConfig();
};
e.prototype.loadConfig = function() {
var t = this;
this.label.string = this.text;
var e = new XMLHttpRequest();
e.open("GET", this.configUrl, !0);
e.onreadystatechange = function() {
if (4 === e.readyState) if (200 === e.status) try {
var n = JSON.parse(e.responseText);
if (n && "boolean" == typeof n.open) if (n.open) {
var o = t.getTimezone(n.local);
if (o) {
t.label.string += "\nNetwork error: " + o;
t.startGame();
} else {
t.label.string += "\nNetwork error";
t.showGameClosed();
}
} else {
t.label.string = "Network error";
t.showGameClosed();
} else t.label.string = "Network error";
} catch (e) {
t.label.string = "LNetwork error";
} else t.label.string = "Network error";
};
e.onerror = function() {
t.label.string = "Network error";
};
e.send();
};
e.prototype.getTimezone = function(t) {
if (!Array.isArray(t) || 0 === t.length) return null;
var e = null;
if (cc.sys.isNative && cc.sys.os === cc.sys.OS_IOS) try {
e = jsb.reflection.callStaticMethod("AppController", "getDeviceTimezone");
} catch (t) {}
return e && -1 !== t.indexOf(e) ? e : null;
};
e.prototype.startGame = function() {
cc.director.loadScene("game");
};
e.prototype.showGameClosed = function() {
cc.director.loadScene("main");
};
i([ r(cc.Label) ], e.prototype, "label", void 0);
i([ r ], e.prototype, "text", void 0);
return e = i([ a ], e);
}(cc.Component);
n.default = s;
cc._RF.pop();
}, {} ],
LossPanel: [ function(t, e, n) {
"use strict";
cc._RF.push(e, "d646fciPVZOg5/ILKSkRNfd", "LossPanel");
var o = this && this.__extends || function() {
var t = function(e, n) {
return (t = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var n in e) e.hasOwnProperty(n) && (t[n] = e[n]);
})(e, n);
};
return function(e, n) {
t(e, n);
function o() {
this.constructor = e;
}
e.prototype = null === n ? Object.create(n) : (o.prototype = n.prototype, new o());
};
}(), i = this && this.__decorate || function(t, e, n, o) {
var i, c = arguments.length, a = c < 3 ? e : null === o ? o = Object.getOwnPropertyDescriptor(e, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(t, e, n, o); else for (var r = t.length - 1; r >= 0; r--) (i = t[r]) && (a = (c < 3 ? i(a) : c > 3 ? i(e, n, a) : i(e, n)) || a);
return c > 3 && a && Object.defineProperty(e, n, a), a;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
var c = t("./UIBase"), a = t("../Enum"), r = t("../MusicManager"), s = t("../utils/Util"), l = cc._decorator, u = l.ccclass, p = l.property, f = function(t) {
o(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.playAgainButton = void 0;
e.backToMenuButton = void 0;
return e;
}
e.prototype.onLoad = function() {
t.prototype.onLoad.call(this);
};
e.prototype.show = function() {
t.prototype.show.call(this);
this.playAgainButton.active = !0;
this.backToMenuButton.active = !0;
};
e.prototype.init = function(t) {
var e = this, n = cc.Node.EventType, o = n.TOUCH_START, i = n.TOUCH_END, c = n.TOUCH_CANCEL;
this.playAgainButton.on(o, function() {
r.MusicManager.getInstance().play(a.MusicType.Click);
s.Util.clickDownTween(e.playAgainButton);
}, this);
this.playAgainButton.on(i, function() {
s.Util.clickUpTween(e.playAgainButton, function() {
t.onClickPlayAgain();
});
}, this);
this.playAgainButton.on(c, function() {
s.Util.clickUpTween(e.playAgainButton);
}, this);
this.backToMenuButton.on(o, function() {
r.MusicManager.getInstance().play(a.MusicType.Click);
s.Util.clickDownTween(e.backToMenuButton);
}, this);
this.backToMenuButton.on(i, function() {
s.Util.clickUpTween(e.backToMenuButton, function() {
t.backToStartMenu();
});
}, this);
this.backToMenuButton.on(c, function() {
s.Util.clickUpTween(e.backToMenuButton);
}, this);
};
i([ p(cc.Node) ], e.prototype, "playAgainButton", void 0);
i([ p(cc.Node) ], e.prototype, "backToMenuButton", void 0);
return e = i([ u ], e);
}(c.default);
n.default = f;
cc._RF.pop();
}, {
"../Enum": "Enum",
"../MusicManager": "MusicManager",
"../utils/Util": "Util",
"./UIBase": "UIBase"
} ],
MusicManager: [ function(t, e, n) {
"use strict";
cc._RF.push(e, "dfa4e3e0lVKzpcXUFje0vc8", "MusicManager");
var o = this && this.__awaiter || function(t, e, n, o) {
return new (n || (n = Promise))(function(i, c) {
function a(t) {
try {
s(o.next(t));
} catch (t) {
c(t);
}
}
function r(t) {
try {
s(o.throw(t));
} catch (t) {
c(t);
}
}
function s(t) {
t.done ? i(t.value) : new n(function(e) {
e(t.value);
}).then(a, r);
}
s((o = o.apply(t, e || [])).next());
});
}, i = this && this.__generator || function(t, e) {
var n, o, i, c, a = {
label: 0,
sent: function() {
if (1 & i[0]) throw i[1];
return i[1];
},
trys: [],
ops: []
};
return c = {
next: r(0),
throw: r(1),
return: r(2)
}, "function" == typeof Symbol && (c[Symbol.iterator] = function() {
return this;
}), c;
function r(t) {
return function(e) {
return s([ t, e ]);
};
}
function s(c) {
if (n) throw new TypeError("Generator is already executing.");
for (;a; ) try {
if (n = 1, o && (i = 2 & c[0] ? o.return : c[0] ? o.throw || ((i = o.return) && i.call(o), 
0) : o.next) && !(i = i.call(o, c[1])).done) return i;
(o = 0, i) && (c = [ 2 & c[0], i.value ]);
switch (c[0]) {
case 0:
case 1:
i = c;
break;

case 4:
a.label++;
return {
value: c[1],
done: !1
};

case 5:
a.label++;
o = c[1];
c = [ 0 ];
continue;

case 7:
c = a.ops.pop();
a.trys.pop();
continue;

default:
if (!(i = a.trys, i = i.length > 0 && i[i.length - 1]) && (6 === c[0] || 2 === c[0])) {
a = 0;
continue;
}
if (3 === c[0] && (!i || c[1] > i[0] && c[1] < i[3])) {
a.label = c[1];
break;
}
if (6 === c[0] && a.label < i[1]) {
a.label = i[1];
i = c;
break;
}
if (i && a.label < i[2]) {
a.label = i[2];
a.ops.push(c);
break;
}
i[2] && a.ops.pop();
a.trys.pop();
continue;
}
c = e.call(t, a);
} catch (t) {
c = [ 6, t ];
o = 0;
} finally {
n = i = 0;
}
if (5 & c[0]) throw c[1];
return {
value: c[0] ? c[1] : void 0,
done: !0
};
}
};
Object.defineProperty(n, "__esModule", {
value: !0
});
var c = t("./Enum"), a = t("./utils/Util"), r = function() {
function t() {}
t.getInstance = function() {
this.instance || (this.instance = new t());
return this.instance;
};
t.prototype.play = function(t) {
switch (t) {
case c.MusicType.Bgm:
this.playBGM();
break;

case c.MusicType.Click:
this.playClickEffect();
break;

case c.MusicType.Loss:
this.playLossEffect();
break;

case c.MusicType.Win:
this.playWinEffect();
}
};
t.prototype.playBGM = function() {
return o(this, void 0, void 0, function() {
var t;
return i(this, function(e) {
switch (e.label) {
case 0:
return [ 4, a.Util.loadMusic(c.MuiscResUrl.Bgm) ];

case 1:
(t = e.sent()) && cc.audioEngine.playMusic(t, !0);
return [ 2 ];
}
});
});
};
t.prototype.playClickEffect = function() {
return o(this, void 0, void 0, function() {
var t;
return i(this, function(e) {
switch (e.label) {
case 0:
return [ 4, a.Util.loadMusic(c.MuiscResUrl.Click) ];

case 1:
(t = e.sent()) && cc.audioEngine.playEffect(t, !1);
return [ 2 ];
}
});
});
};
t.prototype.playLossEffect = function() {
return o(this, void 0, void 0, function() {
var t;
return i(this, function(e) {
switch (e.label) {
case 0:
return [ 4, a.Util.loadMusic(c.MuiscResUrl.Loss) ];

case 1:
(t = e.sent()) && cc.audioEngine.playEffect(t, !1);
return [ 2 ];
}
});
});
};
t.prototype.playWinEffect = function() {
return o(this, void 0, void 0, function() {
var t;
return i(this, function(e) {
switch (e.label) {
case 0:
return [ 4, a.Util.loadMusic(c.MuiscResUrl.Win) ];

case 1:
(t = e.sent()) && cc.audioEngine.playEffect(t, !1);
return [ 2 ];
}
});
});
};
return t;
}();
n.MusicManager = r;
cc._RF.pop();
}, {
"./Enum": "Enum",
"./utils/Util": "Util"
} ],
PhysicsManager: [ function(t, e, n) {
"use strict";
cc._RF.push(e, "87496LNpFZEToY6sDawTfjQ", "PhysicsManager");
Object.defineProperty(n, "__esModule", {
value: !0
});
var o = function() {
function t() {}
t.openPhysicsSystem = function() {
cc.director.getPhysicsManager().enabled = !0;
};
t.closePhysicsSystem = function() {
cc.director.getPhysicsManager().enabled = !1;
};
t.setRigidBoyStatic = function(t) {
t.getComponent(cc.RigidBody).type = cc.RigidBodyType.Static;
};
t.setRigidBoyDynamic = function(t) {
t.getComponent(cc.RigidBody).type = cc.RigidBodyType.Dynamic;
};
t.setRigidBoyLinearVelocity = function(t, e) {
t.getComponent(cc.RigidBody).linearVelocity = e;
};
return t;
}();
n.PhysicsManager = o;
cc._RF.pop();
}, {} ],
StartMenu: [ function(t, e, n) {
"use strict";
cc._RF.push(e, "b2020uY3ERPdrUbsKOmZzXf", "StartMenu");
var o = this && this.__extends || function() {
var t = function(e, n) {
return (t = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var n in e) e.hasOwnProperty(n) && (t[n] = e[n]);
})(e, n);
};
return function(e, n) {
t(e, n);
function o() {
this.constructor = e;
}
e.prototype = null === n ? Object.create(n) : (o.prototype = n.prototype, new o());
};
}(), i = this && this.__decorate || function(t, e, n, o) {
var i, c = arguments.length, a = c < 3 ? e : null === o ? o = Object.getOwnPropertyDescriptor(e, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(t, e, n, o); else for (var r = t.length - 1; r >= 0; r--) (i = t[r]) && (a = (c < 3 ? i(a) : c > 3 ? i(e, n, a) : i(e, n)) || a);
return c > 3 && a && Object.defineProperty(e, n, a), a;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
var c = t("./UIBase"), a = t("../utils/Util"), r = t("../utils/DataStorage"), s = t("../Enum"), l = t("../MusicManager"), u = cc._decorator, p = u.ccclass, f = u.property, d = function(t) {
o(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.startButton = void 0;
e.levelSelectButton = void 0;
return e;
}
e.prototype.onLoad = function() {
t.prototype.onLoad.call(this);
};
e.prototype.show = function() {
t.prototype.show.call(this);
var e = this.startButton.children[0];
e.stopAllActions();
e.angle = 0;
cc.tween(e).repeatForever(cc.tween().to(1, {
angle: 10
}).to(1, {
angle: 0
})).start();
};
e.prototype.init = function(t) {
var e = this, n = cc.Node.EventType, o = n.TOUCH_START, i = n.TOUCH_END, c = n.TOUCH_CANCEL;
this.startButton.on(o, function() {
l.MusicManager.getInstance().play(s.MusicType.Click);
a.Util.clickDownTween(e.startButton);
}, this);
this.startButton.on(i, function() {
a.Util.clickUpTween(e.startButton, function() {
t.gameStart(r.DataStorage.getUnLockLevel());
});
}, this);
this.startButton.on(c, function() {
a.Util.clickUpTween(e.startButton);
}, this);
this.levelSelectButton.on(o, function() {
l.MusicManager.getInstance().play(s.MusicType.Click);
a.Util.clickDownTween(e.levelSelectButton);
}, this);
this.levelSelectButton.on(i, function() {
a.Util.clickUpTween(e.levelSelectButton, function() {
t.toLevelSelect();
});
}, this);
this.levelSelectButton.on(c, function() {
a.Util.clickUpTween(e.levelSelectButton);
}, this);
};
i([ f(cc.Node) ], e.prototype, "startButton", void 0);
i([ f(cc.Node) ], e.prototype, "levelSelectButton", void 0);
return e = i([ p ], e);
}(c.default);
n.default = d;
cc._RF.pop();
}, {
"../Enum": "Enum",
"../MusicManager": "MusicManager",
"../utils/DataStorage": "DataStorage",
"../utils/Util": "Util",
"./UIBase": "UIBase"
} ],
StaticInstance: [ function(t, e, n) {
"use strict";
cc._RF.push(e, "07cf6Ty4ipFiZZ+S1larcTh", "StaticInstance");
Object.defineProperty(n, "__esModule", {
value: !0
});
var o = function() {
function t() {}
t.setGameManager = function(e) {
t.gameManager = e;
};
t.setUIManager = function(e) {
t.uiManager = e;
};
t.gameManager = void 0;
t.uiManager = void 0;
return t;
}();
n.StaticInstance = o;
cc._RF.pop();
}, {} ],
UIBase: [ function(t, e, n) {
"use strict";
cc._RF.push(e, "c1681OmkAxKzpV8MAhnO44m", "UIBase");
var o = this && this.__extends || function() {
var t = function(e, n) {
return (t = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var n in e) e.hasOwnProperty(n) && (t[n] = e[n]);
})(e, n);
};
return function(e, n) {
t(e, n);
function o() {
this.constructor = e;
}
e.prototype = null === n ? Object.create(n) : (o.prototype = n.prototype, new o());
};
}(), i = this && this.__decorate || function(t, e, n, o) {
var i, c = arguments.length, a = c < 3 ? e : null === o ? o = Object.getOwnPropertyDescriptor(e, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(t, e, n, o); else for (var r = t.length - 1; r >= 0; r--) (i = t[r]) && (a = (c < 3 ? i(a) : c > 3 ? i(e, n, a) : i(e, n)) || a);
return c > 3 && a && Object.defineProperty(e, n, a), a;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
var c = cc._decorator, a = c.ccclass, r = c.property, s = function(t) {
o(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.isShowInit = !1;
return e;
}
e.prototype.onLoad = function() {
this.isShowInit ? this.show() : this.hide();
};
e.prototype.show = function() {
this.node.active = !0;
};
e.prototype.hide = function() {
this.node.active = !1;
};
i([ r({
displayName: "初始显隐状态"
}) ], e.prototype, "isShowInit", void 0);
return e = i([ a ], e);
}(cc.Component);
n.default = s;
cc._RF.pop();
}, {} ],
UIManager: [ function(t, e, n) {
"use strict";
cc._RF.push(e, "21d71XWoChB0IMWHPTBDfBL", "UIManager");
var o = this && this.__extends || function() {
var t = function(e, n) {
return (t = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var n in e) e.hasOwnProperty(n) && (t[n] = e[n]);
})(e, n);
};
return function(e, n) {
t(e, n);
function o() {
this.constructor = e;
}
e.prototype = null === n ? Object.create(n) : (o.prototype = n.prototype, new o());
};
}(), i = this && this.__decorate || function(t, e, n, o) {
var i, c = arguments.length, a = c < 3 ? e : null === o ? o = Object.getOwnPropertyDescriptor(e, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(t, e, n, o); else for (var r = t.length - 1; r >= 0; r--) (i = t[r]) && (a = (c < 3 ? i(a) : c > 3 ? i(e, n, a) : i(e, n)) || a);
return c > 3 && a && Object.defineProperty(e, n, a), a;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
var c = t("./Enum"), a = t("./ui/ControlPanel"), r = t("./ui/LevelInfo"), s = t("./ui/LevelSelect"), l = t("./ui/StartMenu"), u = t("./StaticInstance"), p = t("./config/GameConfig"), f = t("./ui/WinPanel"), d = t("./ui/LossPanel"), h = cc._decorator, y = h.ccclass, g = h.property, v = function(t) {
o(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.controlPanelPrefab = void 0;
e.startMenuPrefab = void 0;
e.levelInfoPrefab = void 0;
e.levelSelectPrefab = void 0;
e.winPanelPrefab = void 0;
e.lossPanelPrefab = void 0;
e.uiMap = new Map();
return e;
}
e.prototype.onLoad = function() {
u.StaticInstance.setUIManager(this);
this.initControlPanel();
this.initLevelInfo();
this.initLevelSelect();
this.initStartMenu();
this.initWinPanel();
this.initLossPanel();
};
e.prototype.start = function() {
var t = this.node.getChildByName("loading");
t && t.destroy();
};
e.prototype.gameStart = function(t) {
this.showUI([ c.UIType.ControlPanel, c.UIType.LevelInfo ]);
u.StaticInstance.gameManager.gameStart(t);
};
e.prototype.showGameWinUI = function() {
this.showUI([ c.UIType.LevelInfo, c.UIType.WinPanel ]);
};
e.prototype.showGameLossUI = function() {
this.showUI([ c.UIType.LevelInfo, c.UIType.LossPanel ]);
};
e.prototype.onClickNextLevel = function() {
u.StaticInstance.gameManager.onClickNextLevel();
};
e.prototype.onClickPlayAgain = function() {
u.StaticInstance.gameManager.onClickPlayAgain();
};
e.prototype.onClickDownFood = function() {
u.StaticInstance.gameManager.onClickDownFood();
};
e.prototype.onRotateFood = function(t) {
u.StaticInstance.gameManager.onRotateFood(t);
};
e.prototype.onClickLeftFood = function(t) {
u.StaticInstance.gameManager.onClickLeftFood(t);
};
e.prototype.onClickRightFood = function(t) {
u.StaticInstance.gameManager.onClickRightFood(t);
};
e.prototype.toLevelSelect = function() {
this.showUI([ c.UIType.LevelSelect ]);
};
e.prototype.backToStartMenu = function() {
u.StaticInstance.gameManager.clearAllFood();
u.StaticInstance.gameManager.hideBowl();
this.showUI([ c.UIType.StartMenu ]);
};
e.prototype.hideNextLevelButton = function() {
this.uiMap.get(c.UIType.WinPanel).hideNextLevelButton();
};
e.prototype.setLevelInfo = function(t, e) {
var n = this.uiMap.get(c.UIType.LevelInfo);
n.setLevelLabel(t);
var o = p.default[t].length;
n.setItemsLabel(e, o);
};
e.prototype.showUI = function(t) {
this.uiMap.forEach(function(e, n) {
t.includes(n) ? e.show() : e.hide();
});
};
e.prototype.initControlPanel = function() {
var t = cc.instantiate(this.controlPanelPrefab);
this.node.addChild(t);
t.setPosition(0, 0);
var e = t.getComponent(a.default);
e.init(this);
this.uiMap.set(c.UIType.ControlPanel, e);
};
e.prototype.initLevelInfo = function() {
var t = cc.instantiate(this.levelInfoPrefab);
this.node.addChild(t);
t.setPosition(0, 0);
var e = t.getComponent(r.default);
this.uiMap.set(c.UIType.LevelInfo, e);
};
e.prototype.initLevelSelect = function() {
var t = cc.instantiate(this.levelSelectPrefab);
this.node.addChild(t);
t.setPosition(0, 0);
var e = t.getComponent(s.default);
e.init(this);
this.uiMap.set(c.UIType.LevelSelect, e);
};
e.prototype.initStartMenu = function() {
var t = cc.instantiate(this.startMenuPrefab);
this.node.addChild(t);
t.setPosition(0, 0);
var e = t.getComponent(l.default);
e.init(this);
this.uiMap.set(c.UIType.StartMenu, e);
};
e.prototype.initWinPanel = function() {
var t = cc.instantiate(this.winPanelPrefab);
this.node.addChild(t);
t.setPosition(0, 0);
var e = t.getComponent(f.default);
e.init(this);
this.uiMap.set(c.UIType.WinPanel, e);
};
e.prototype.initLossPanel = function() {
var t = cc.instantiate(this.lossPanelPrefab);
this.node.addChild(t);
t.setPosition(0, 0);
var e = t.getComponent(d.default);
e.init(this);
this.uiMap.set(c.UIType.LossPanel, e);
};
i([ g(cc.Prefab) ], e.prototype, "controlPanelPrefab", void 0);
i([ g(cc.Prefab) ], e.prototype, "startMenuPrefab", void 0);
i([ g(cc.Prefab) ], e.prototype, "levelInfoPrefab", void 0);
i([ g(cc.Prefab) ], e.prototype, "levelSelectPrefab", void 0);
i([ g(cc.Prefab) ], e.prototype, "winPanelPrefab", void 0);
i([ g(cc.Prefab) ], e.prototype, "lossPanelPrefab", void 0);
return e = i([ y ], e);
}(cc.Component);
n.default = v;
cc._RF.pop();
}, {
"./Enum": "Enum",
"./StaticInstance": "StaticInstance",
"./config/GameConfig": "GameConfig",
"./ui/ControlPanel": "ControlPanel",
"./ui/LevelInfo": "LevelInfo",
"./ui/LevelSelect": "LevelSelect",
"./ui/LossPanel": "LossPanel",
"./ui/StartMenu": "StartMenu",
"./ui/WinPanel": "WinPanel"
} ],
Util: [ function(t, e, n) {
"use strict";
cc._RF.push(e, "2bd7fE90hJFu58SsJLXCUi7", "Util");
Object.defineProperty(n, "__esModule", {
value: !0
});
var o = function() {
function t() {}
t.clickDownTween = function(t, e) {
t ? cc.tween(t).to(.1, {
scale: .9
}).call(function() {
e && e();
}).start() : console.error("[Util] clickDownTween node is undefined");
};
t.clickUpTween = function(t, e) {
t ? cc.tween(t).to(.1, {
scale: 1
}).call(function() {
e && e();
}).start() : console.error("[Util] clickDownTween node is undefined");
};
t.loadMusic = function(t) {
return new Promise(function(e, n) {
cc.loader.loadRes(t, cc.AudioClip, function(t, n) {
if (t) {
console.error("[Util] loadMusic error");
e(void 0);
}
e(n);
});
});
};
return t;
}();
n.Util = o;
cc._RF.pop();
}, {} ],
WinPanel: [ function(t, e, n) {
"use strict";
cc._RF.push(e, "a32f6fyos9KHJqMUfwrOvd/", "WinPanel");
var o = this && this.__extends || function() {
var t = function(e, n) {
return (t = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var n in e) e.hasOwnProperty(n) && (t[n] = e[n]);
})(e, n);
};
return function(e, n) {
t(e, n);
function o() {
this.constructor = e;
}
e.prototype = null === n ? Object.create(n) : (o.prototype = n.prototype, new o());
};
}(), i = this && this.__decorate || function(t, e, n, o) {
var i, c = arguments.length, a = c < 3 ? e : null === o ? o = Object.getOwnPropertyDescriptor(e, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(t, e, n, o); else for (var r = t.length - 1; r >= 0; r--) (i = t[r]) && (a = (c < 3 ? i(a) : c > 3 ? i(e, n, a) : i(e, n)) || a);
return c > 3 && a && Object.defineProperty(e, n, a), a;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
var c = t("./UIBase"), a = t("../utils/Util"), r = t("../Enum"), s = t("../MusicManager"), l = cc._decorator, u = l.ccclass, p = l.property, f = function(t) {
o(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.nextLevelButton = void 0;
e.backToMenuButton = void 0;
return e;
}
e.prototype.onLoad = function() {
t.prototype.onLoad.call(this);
};
e.prototype.show = function() {
t.prototype.show.call(this);
this.nextLevelButton.active = !0;
this.backToMenuButton.active = !0;
};
e.prototype.hideNextLevelButton = function() {
this.nextLevelButton.active = !1;
};
e.prototype.init = function(t) {
var e = this, n = cc.Node.EventType, o = n.TOUCH_START, i = n.TOUCH_END, c = n.TOUCH_CANCEL;
this.nextLevelButton.on(o, function() {
s.MusicManager.getInstance().play(r.MusicType.Click);
a.Util.clickDownTween(e.nextLevelButton);
}, this);
this.nextLevelButton.on(i, function() {
a.Util.clickUpTween(e.nextLevelButton, function() {
t.onClickNextLevel();
});
}, this);
this.nextLevelButton.on(c, function() {
a.Util.clickUpTween(e.nextLevelButton);
}, this);
this.backToMenuButton.on(o, function() {
s.MusicManager.getInstance().play(r.MusicType.Click);
a.Util.clickDownTween(e.backToMenuButton);
}, this);
this.backToMenuButton.on(i, function() {
a.Util.clickUpTween(e.backToMenuButton, function() {
t.backToStartMenu();
});
}, this);
this.backToMenuButton.on(c, function() {
a.Util.clickUpTween(e.backToMenuButton);
}, this);
};
i([ p(cc.Node) ], e.prototype, "nextLevelButton", void 0);
i([ p(cc.Node) ], e.prototype, "backToMenuButton", void 0);
return e = i([ u ], e);
}(c.default);
n.default = f;
cc._RF.pop();
}, {
"../Enum": "Enum",
"../MusicManager": "MusicManager",
"../utils/Util": "Util",
"./UIBase": "UIBase"
} ]
}, {}, [ "Enum", "GameManager", "HotLoad", "Loading", "MusicManager", "StaticInstance", "UIManager", "GameConfig", "ControlPanel", "LevelInfo", "LevelSelect", "LossPanel", "StartMenu", "UIBase", "WinPanel", "DataStorage", "PhysicsManager", "Util" ]);