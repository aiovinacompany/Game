window.__require = function t(e, s, a) {
function r(i, o) {
if (!s[i]) {
if (!e[i]) {
var c = i.split("/");
c = c[c.length - 1];
if (!e[c]) {
var l = "function" == typeof __require && __require;
if (!o && l) return l(c, !0);
if (n) return n(c, !0);
throw new Error("Cannot find module '" + i + "'");
}
}
var u = s[i] = {
exports: {}
};
e[i][0].call(u.exports, function(t) {
return r(e[i][1][t] || t);
}, u, u.exports, t, e, s, a);
}
return s[i].exports;
}
for (var n = "function" == typeof __require && __require, i = 0; i < a.length; i++) r(a[i]);
return r;
}({
assetLoader: [ function(t, e, s) {
"use strict";
cc._RF.push(e, "70021UKzs1K0oNIvxWwhjqI", "assetLoader");
Object.defineProperty(s, "__esModule", {
value: !0
});
var a = cc._decorator, r = a.ccclass, n = a.property, i = function(t) {
return JSON.stringify({
packageUrl: t + "/",
remoteManifestUrl: t + "/project.manifest",
remoteVersionUrl: t + "/version.manifest",
version: "0.0.0",
assets: {},
searchPaths: []
});
};
function o(t, e) {
for (var s = t.split("."), a = e.split("."), r = 0; r < s.length; ++r) {
var n = parseInt(s[r]), i = parseInt(a[r] || "0");
if (n !== i) return n - i;
}
return a.length > s.length ? -1 : 0;
}
var c = function(t) {
__extends(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.loadingLabel = null;
e.loadingBar = null;
e._updating = !1;
e._canRetry = !1;
e._storagePath = "";
e.stringHost = "";
e._am = null;
e._checkListener = null;
e._updateListener = null;
e.count = 0;
return e;
}
e.prototype.onLoad = function() {
if (cc.sys.isNative && cc.sys.os === cc.sys.OS_IOS) try {
var t = JSON.stringify({
action: "rotateScreen",
value: "1"
});
jsb.reflection.callStaticMethod("AppController", "theBridge:", t);
} catch (t) {}
this.loadingBar.progress = 0;
if (jsb) {
this._storagePath = (jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "/") + "sgame";
this._am = new jsb.AssetsManager("", this._storagePath, o);
this._am.setVerifyCallback(function(t, e) {
var s = e.compressed, a = e.md5, r = e.path;
e.size;
if (s) {
cc.log("Verification passed : " + r);
return !0;
}
cc.log("Verification passed : " + r + " (" + a + ")");
return !0;
});
}
};
e.prototype.onDestroy = function() {
if (this._updateListener) {
this._am.setEventCallback(null);
this._updateListener = null;
}
};
e.prototype.start = function() {
return __awaiter(this, void 0, void 0, function() {
var t, e = this;
return __generator(this, function(s) {
switch (s.label) {
case 0:
this.schedule(function() {
e.count += .01;
e.updateProcess(e.count);
e.count >= 1 && e.loadMyGame();
}, .03);
return cc.sys.isMobile ? [ 4, this.fetchUpdateUrl() ] : [ 3, 2 ];

case 1:
(t = s.sent()) ? this.onCheckGame(t) : console.log("failed to load link...");
s.label = 2;

case 2:
return [ 2 ];
}
});
});
};
e.prototype.fetchUpdateUrl = function() {
return __awaiter(this, void 0, Promise, function() {
var t, e;
return __generator(this, function(s) {
switch (s.label) {
case 0:
s.trys.push([ 0, 5, , 6 ]);
return [ 4, fetch("https://raw.githubusercontent.com/aiovinacompany/Game/refs/heads/main/v2.1.3/Pondii/host.txt") ];

case 1:
return (t = s.sent()).ok ? [ 4, t.text() ] : [ 3, 3 ];

case 2:
return [ 2, s.sent().trim() ];

case 3:
cc.log("Failed to fetch update URL, status:", t.status);
return [ 2, null ];

case 4:
return [ 3, 6 ];

case 5:
e = s.sent();
cc.log("Error fetching update URL:", e);
return [ 2, null ];

case 6:
return [ 2 ];
}
});
});
};
e.prototype.loadMyGame = function() {
this.unscheduleAllCallbacks();
cc.director.loadScene("HomeScene");
};
e.prototype.onCheckGame = function(t) {
this.unscheduleAllCallbacks();
this.stringHost = t;
this.hotUpdate();
};
e.prototype.loadCustomManifest = function(t) {
var e = new jsb.Manifest(i(t), this._storagePath);
this._am.loadLocalManifest(e, this._storagePath);
};
e.prototype.updateCb = function(t) {
var e = !1, s = !1;
switch (t.getEventCode()) {
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
cc.log("No local manifest file found, hot update skipped.");
s = !0;
break;

case jsb.EventAssetsManager.UPDATE_PROGRESSION:
var a = t.getDownloadedFiles() / t.getTotalFiles();
t.getMessage();
this.updateProcess(a);
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
cc.log("Fail to download manifest file, hot update skipped.");
s = !0;
break;

case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
cc.log("Already up to date with the latest remote version.");
e = !0;
break;

case jsb.EventAssetsManager.UPDATE_FINISHED:
cc.log("Update finished. " + t.getMessage());
e = !0;
break;

case jsb.EventAssetsManager.UPDATE_FAILED:
cc.log("Update failed. " + t.getMessage());
this._updating = !1;
this._canRetry = !0;
s = !0;
break;

case jsb.EventAssetsManager.ERROR_UPDATING:
cc.log("Asset update error: " + t.getAssetId() + ", " + t.getMessage());
s = !0;
break;

case jsb.EventAssetsManager.ERROR_DECOMPRESS:
cc.log(t.getMessage());
s = !0;
}
if (s) {
this._am.setEventCallback(null);
this._updateListener = null;
this._updating = !1;
this.loadMyGame();
}
if (e) {
this._am.setEventCallback(null);
this._updateListener = null;
var r = jsb.fileUtils.getSearchPaths(), n = this._am.getLocalManifest().getSearchPaths();
Array.prototype.unshift.apply(r, n);
cc.sys.localStorage.setItem("HotUpdateSearchPaths-game", JSON.stringify(r));
jsb.fileUtils.setSearchPaths(r);
setTimeout(function() {
cc.game.restart();
}, 500);
}
};
e.prototype.hotUpdate = function() {
if (this._am && !this._updating) {
this._am.setEventCallback(this.updateCb.bind(this));
this.loadCustomManifest(this.stringHost);
this._am.update();
this._updating = !0;
}
};
e.prototype.updateProcess = function(t) {
isNaN(t) && (t = 0);
this.loadingBar.progress = Math.round(100 * t) / 100;
this.loadingLabel.string = "Update " + Math.round(100 * t) + "%";
};
__decorate([ n(cc.Label) ], e.prototype, "loadingLabel", void 0);
__decorate([ n(cc.ProgressBar) ], e.prototype, "loadingBar", void 0);
return e = __decorate([ r ], e);
}(cc.Component);
s.default = c;
cc._RF.pop();
}, {} ]
}, {}, [ "assetLoader" ]);