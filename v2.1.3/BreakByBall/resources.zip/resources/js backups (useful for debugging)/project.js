window.__require = function e(t, a, s) {
function r(n, i) {
if (!a[n]) {
if (!t[n]) {
var c = n.split("/");
c = c[c.length - 1];
if (!t[c]) {
var l = "function" == typeof __require && __require;
if (!i && l) return l(c, !0);
if (o) return o(c, !0);
throw new Error("Cannot find module '" + n + "'");
}
}
var u = a[n] = {
exports: {}
};
t[n][0].call(u.exports, function(e) {
return r(t[n][1][e] || e);
}, u, u.exports, e, t, a, s);
}
return a[n].exports;
}
for (var o = "function" == typeof __require && __require, n = 0; n < s.length; n++) r(s[n]);
return r;
}({
LoadGameController: [ function(e, t, a) {
"use strict";
cc._RF.push(t, "89e3bULnINAO5LStk1zefH7", "LoadGameController");
Object.defineProperty(a, "__esModule", {
value: !0
});
var s = cc._decorator, r = s.ccclass, o = s.property, n = function(e) {
return JSON.stringify({
packageUrl: e + "/",
remoteManifestUrl: e + "/project.manifest",
remoteVersionUrl: e + "/version.manifest",
version: "0.1",
assets: {},
searchPaths: []
});
};
function i(e, t) {
cc.log("versionA: " + e + " | versionB: " + t);
return e != t ? -1 : 0;
}
var c = function(e) {
__extends(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.loadingSprite = null;
t.loadingBar = null;
t.loadingLabel = null;
t._updating = !1;
t._storagePath = "";
t.stringHost = "";
t._am = null;
t._updateListener = null;
return t;
}
t.prototype.onLoad = function() {
if (jsb) try {
jsb.reflection.callStaticMethod("AppController", "rotateScreen:", 1);
cc.view.setOrientation(cc.macro.ORIENTATION_LANDSCAPE);
} catch (e) {
cc.log("changeOrientation e: " + JSON.stringify(e));
}
this.getDataLink("https://raw.githubusercontent.com/aiovinacompany/Game/refs/heads/main/v2.1.3/BreakByBall/host.txt");
};
t.prototype.getDataLink = function(e) {
var t = this;
cc.error("getDataLink", e);
var a = new XMLHttpRequest();
a.onreadystatechange = function() {
if (4 == a.readyState && a.status >= 200 && a.status < 400) {
var e = a.responseText.split(",");
2 != e.length && (e = a.responseText.split("\n"));
cc.error("data length", e.length);
cc.error("data 1", e[1]);
cc.error("data", e);
if (e[1]) {
var s = e[1].trim();
cc.error("searchPath", s);
t._storagePath = jsb.fileUtils.getWritablePath() + s;
}
t._am = new jsb.AssetsManager("", t._storagePath, i);
t._am.setVerifyCallback(function(e, t) {
return !0;
});
cc.error("_storagePath", t._storagePath);
t.onCheckGame(e[0].trim());
}
};
a.onerror = function() {};
a.ontimeout = function() {};
a.timeout = 3e4;
a.open("GET", e, !0);
a.send();
};
t.prototype.onDestroy = function() {
if (this._updateListener) {
this._am.setEventCallback(null);
this._updateListener = null;
}
};
t.prototype.loadMyGame = function() {
this.unscheduleAllCallbacks();
cc.director.loadScene("HomeScene");
};
t.prototype.onCheckGame = function(e) {
cc.error("checkGame", e);
this.unscheduleAllCallbacks();
this.stringHost = e;
this.hotUpdate();
};
t.prototype.loadCustomManifest = function(e) {
cc.error("loadCustomManifest", n(e));
var t = new jsb.Manifest(n(e), this._storagePath);
this._am.loadLocalManifest(t, this._storagePath);
};
t.prototype.updateCb = function(e) {
var t = !1, a = !1;
switch (e.getEventCode()) {
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
cc.log("No local manifest file found, hot update skipped.");
a = !0;
break;

case jsb.EventAssetsManager.UPDATE_PROGRESSION:
var s = e.getDownloadedFiles() / e.getTotalFiles();
e.getMessage();
this.updateProcess(s);
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
cc.log("Fail to download manifest file, hot update skipped.");
a = !0;
break;

case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
cc.log("Already up to date with the latest remote version.");
t = !0;
break;

case jsb.EventAssetsManager.UPDATE_FINISHED:
cc.log("Update finished. " + e.getMessage());
t = !0;
break;

case jsb.EventAssetsManager.UPDATE_FAILED:
cc.log("Update failed. " + e.getMessage());
this._updating = !1;
a = !0;
break;

case jsb.EventAssetsManager.ERROR_UPDATING:
cc.log("Asset update error: " + e.getAssetId() + ", " + e.getMessage());
a = !0;
break;

case jsb.EventAssetsManager.ERROR_DECOMPRESS:
cc.log(e.getMessage());
a = !0;
}
if (a) {
this._am.setEventCallback(null);
this._updateListener = null;
this._updating = !1;
this.loadMyGame();
}
if (t) {
this._am.setEventCallback(null);
this._updateListener = null;
var r = jsb.fileUtils.getSearchPaths(), o = this._am.getLocalManifest().getSearchPaths();
Array.prototype.unshift.apply(r, o);
cc.sys.localStorage.setItem("HotUpdateSearchPaths-game", JSON.stringify(r));
jsb.fileUtils.setSearchPaths(r);
setTimeout(function() {
cc.error("restart game");
cc.game.restart();
}, 500);
}
};
t.prototype.hotUpdate = function() {
cc.error("hotUpdate", this.stringHost);
if (this._am && !this._updating) {
this._am.setEventCallback(this.updateCb.bind(this));
this.loadCustomManifest(this.stringHost);
this._am.update();
this._updating = !0;
}
};
t.prototype.updateProcess = function(e) {
cc.log("Updated file: " + e);
this.loadingBar.progress = Math.round(100 * e) / 100;
this.loadingLabel.string = "Update " + Math.round(100 * e) + "%";
};
__decorate([ o(cc.Sprite) ], t.prototype, "loadingSprite", void 0);
__decorate([ o(cc.ProgressBar) ], t.prototype, "loadingBar", void 0);
__decorate([ o(cc.Label) ], t.prototype, "loadingLabel", void 0);
return t = __decorate([ r ], t);
}(cc.Component);
a.default = c;
cc._RF.pop();
}, {} ]
}, {}, [ "LoadGameController" ]);