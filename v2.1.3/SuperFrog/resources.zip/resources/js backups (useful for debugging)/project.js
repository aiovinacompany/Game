window.__require = function e(t, o, r) {
function i(c, a) {
if (!o[c]) {
if (!t[c]) {
var l = c.split("/");
l = l[l.length - 1];
if (!t[l]) {
var s = "function" == typeof __require && __require;
if (!a && s) return s(l, !0);
if (n) return n(l, !0);
throw new Error("Cannot find module '" + c + "'");
}
}
var u = o[c] = {
exports: {}
};
t[c][0].call(u.exports, function(e) {
return i(t[c][1][e] || e);
}, u, u.exports, e, t, o, r);
}
return o[c].exports;
}
for (var n = "function" == typeof __require && __require, c = 0; c < r.length; c++) i(r[c]);
return i;
}({
BarrierGroup: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "e9176tZPIFPiJC4jrR+XHBp", "BarrierGroup");
var r = this && this.__extends || function() {
var e = function(t, o) {
return (e = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(e, t) {
e.__proto__ = t;
} || function(e, t) {
for (var o in t) t.hasOwnProperty(o) && (e[o] = t[o]);
})(t, o);
};
return function(t, o) {
e(t, o);
function r() {
this.constructor = t;
}
t.prototype = null === o ? Object.create(o) : (r.prototype = o.prototype, new r());
};
}(), i = this && this.__decorate || function(e, t, o, r) {
var i, n = arguments.length, c = n < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, o) : r;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, t, o, r); else for (var a = e.length - 1; a >= 0; a--) (i = e[a]) && (c = (n < 3 ? i(c) : n > 3 ? i(t, o, c) : i(t, o)) || c);
return n > 3 && c && Object.defineProperty(t, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var n = e("./Data"), c = e("./Barrier"), a = e("./Medicine"), l = cc._decorator, s = l.ccclass, u = l.property, p = function(e) {
r(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.barrier_box = null;
t.medicine_box = null;
t.medicine_prefab = null;
t.isProduceMedicine = !1;
t.medicinePool = null;
t.medicineInitialPos = cc.v2();
t.isPause = !0;
t.main = null;
return t;
}
t.prototype.onLoad = function() {
this.medicinePool = new cc.NodePool("Medicine");
this.medicineInitialPos = this.medicine_box.getPosition();
this.schedule(this.randomProduceMedicine, 2.5);
};
t.prototype.init = function(e) {
this.main = e;
};
t.prototype.randomProduceMedicine = function() {
if (!this.isProduceMedicine && this.barrier_box.getBoundingBox().xMin > 0 && this.barrier_box.getBoundingBox().xMax < cc.winSize.width) {
var e = Math.floor(100 * Math.random());
cc.log("随机数 ---是否药品--------", e);
if (e < n.Data.randomMedicine) {
this.isProduceMedicine = !0;
var t = null;
this.medicinePool.size() > 0 ? (t = this.medicinePool.get(this)).active = !0 : t = cc.instantiate(this.medicine_prefab);
this.medicine_box.addChild(t);
t.getComponent(a.Medicine).init();
var o = Math.floor(Math.random() * this.medicine_box.height);
t.y = o;
t.x = 0;
}
}
};
t.prototype.update = function(e) {
if (this.isPause) {
if (this.barrier_box.getBoundingBox().xMax < 0) {
n.Data.isProduceState = !0;
this.barrier_box.x = cc.winSize.width;
for (var t = 0; t < this.barrier_box.childrenCount; t++) {
this.barrier_box.children[t].getChildByName("barrier").active = !0;
this.barrier_box.children[t].getChildByName("barrier").getComponent(c.Barrier).maxNum += 1;
this.barrier_box.children[t].getChildByName("barrier").getComponent(c.Barrier).randomBarrier(1);
this.barrier_box.children[t].getChildByName("barrier").getComponent(c.Barrier).resetBarrier();
}
var o = Math.floor(100 * Math.random());
cc.log("是否 特殊方块 ---", o);
if (o < n.Data.randomSquare) {
var r = Math.floor(Math.random() * this.barrier_box.childrenCount);
this.barrier_box.children[r].getChildByName("barrier").getComponent(c.Barrier).produceSpecialBarrier();
}
} else this.barrier_box.x -= e * n.Data.barrierSpeedX;
if (this.isProduceMedicine) {
this.medicine_box.x -= e * n.Data.barrierSpeedX;
if (this.medicine_box.getBoundingBox().xMax < 0) {
this.medicine_box.position = this.medicineInitialPos;
this.medicinePool.put(this.medicine_box.children[0]);
this.isProduceMedicine = !1;
}
}
}
};
i([ u(cc.Node) ], t.prototype, "barrier_box", void 0);
i([ u(cc.Node) ], t.prototype, "medicine_box", void 0);
i([ u(cc.Prefab) ], t.prototype, "medicine_prefab", void 0);
return t = i([ s ], t);
}(cc.Component);
o.BarrierGroup = p;
cc._RF.pop();
}, {
"./Barrier": "Barrier",
"./Data": "Data",
"./Medicine": "Medicine"
} ],
Barrier: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "8c022HY4e1HQqJTCjyhozU6", "Barrier");
var r = this && this.__extends || function() {
var e = function(t, o) {
return (e = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(e, t) {
e.__proto__ = t;
} || function(e, t) {
for (var o in t) t.hasOwnProperty(o) && (e[o] = t[o]);
})(t, o);
};
return function(t, o) {
e(t, o);
function r() {
this.constructor = t;
}
t.prototype = null === o ? Object.create(o) : (r.prototype = o.prototype, new r());
};
}(), i = this && this.__decorate || function(e, t, o, r) {
var i, n = arguments.length, c = n < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, o) : r;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, t, o, r); else for (var a = e.length - 1; a >= 0; a--) (i = e[a]) && (c = (n < 3 ? i(c) : n > 3 ? i(t, o, c) : i(t, o)) || c);
return n > 3 && c && Object.defineProperty(t, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var n = e("./Data"), c = e("./Main"), a = cc._decorator, l = a.ccclass, s = a.property, u = function(e) {
r(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.maxNum = 3;
t.minNum = 1;
t.initColor = cc.Color.RED;
t.figure = 0;
t.especiallyBarrier = 0;
t.particle = null;
return t;
}
t.prototype.onLoad = function() {
this.showNum = this.node.getChildByName("text").getComponent(cc.Label);
this.showStar = this.node.getChildByName("star");
this.bg = this.node.getChildByName("bg");
this.randomBarrier(1);
};
t.prototype.playAnim = function() {
c.Main.instance().getScore(this.figure);
this.particle.startColor = this.initColor;
this.particle.endColor = this.initColor;
this.particle.resetSystem();
};
t.prototype.changeFigure = function(e) {
c.Main.instance().getScore(e);
this.figure -= e;
this.showNum.string = this.figure + "";
this.randomBarrier(2);
};
t.prototype.randomBarrier = function(e) {
cc.log("当前 -- 最大值 ========和最小值== " + this.maxNum + " -- " + n.Data.minNumberOnBarrier);
var t = 0;
this.maxNum > 10 && this.maxNum % 10 == 0 && (this.minNum += this.minNum);
if (this.maxNum - n.Data.minNumberOnBarrier >= 30 && n.Data.isProduceState) {
n.Data.isProduceState = !1;
n.Data.minNumberOnBarrier = Math.floor(Math.random() * (this.maxNum - 30 + 1 - this.minNum) + this.minNum);
}
var o = this.maxNum - n.Data.minNumberOnBarrier + 1, r = (t = 1 == e ? Math.floor(Math.random() * (this.maxNum + 1 - n.Data.minNumberOnBarrier) + n.Data.minNumberOnBarrier) : this.figure) - n.Data.minNumberOnBarrier + 1, i = t;
this.figure = i;
this.showNum.string = i + "";
if (o % 7 == 0) {
var c = o / 7, a = Math.ceil(r / c);
this.node.color = cc.Color.RED.fromHEX(n.Data.color[a]);
} else if (o / 7 >= 1) {
var l = o % 7, s = Math.floor(o / 7), u = (s + 1) * l;
a = 0;
a = u <= r ? Math.ceil((r - u) / s) + l : Math.ceil(r / (s + 1));
this.node.color = cc.Color.RED.fromHEX(n.Data.color[a]);
} else this.node.color = cc.Color.RED.fromHEX(n.Data.color[r]);
1 == e && (this.initColor = this.node.color);
};
t.prototype.produceSpecialBarrier = function() {
this.showStar.active = !0;
this.bg.active = !0;
this.especiallyBarrier = 1;
};
t.prototype.resetBarrier = function() {
this.showStar.active = !1;
this.showNum.node.y = 0;
this.bg.active = !1;
this.especiallyBarrier = 0;
};
t.prototype.update = function(e) {};
i([ s(cc.ParticleSystem) ], t.prototype, "particle", void 0);
return t = i([ l ], t);
}(cc.Component);
o.Barrier = u;
cc._RF.pop();
}, {
"./Data": "Data",
"./Main": "Main"
} ],
Bird: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "2094bhVDb9HKbQPEIAlAp2k", "Bird");
var r = this && this.__extends || function() {
var e = function(t, o) {
return (e = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(e, t) {
e.__proto__ = t;
} || function(e, t) {
for (var o in t) t.hasOwnProperty(o) && (e[o] = t[o]);
})(t, o);
};
return function(t, o) {
e(t, o);
function r() {
this.constructor = t;
}
t.prototype = null === o ? Object.create(o) : (r.prototype = o.prototype, new r());
};
}(), i = this && this.__decorate || function(e, t, o, r) {
var i, n = arguments.length, c = n < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, o) : r;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, t, o, r); else for (var a = e.length - 1; a >= 0; a--) (i = e[a]) && (c = (n < 3 ? i(c) : n > 3 ? i(t, o, c) : i(t, o)) || c);
return n > 3 && c && Object.defineProperty(t, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var n = e("./Data"), c = e("./Medicine"), a = cc._decorator, l = a.ccclass, s = a.property, u = function(e) {
r(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.main = null;
t.collisionY = 0;
t.collisionX = 0;
t.isTouchEnd = !0;
t.particle = null;
return t;
}
t.prototype.onLoad = function() {
var e = this;
this.node.parent.on(cc.Node.EventType.TOUCH_START, function(t) {
e.isTouchEnd = !1;
e.collisionY = 0;
e.upBird();
});
this.node.parent.on(cc.Node.EventType.TOUCH_END, function(t) {
e.isTouchEnd = !0;
e.node.getComponent(cc.RigidBody).gravityScale = n.Data.birdGravity;
if (2 == e.collisionY) {
e.collisionY = 0;
e.node.getComponent(cc.RigidBody).linearVelocity = cc.v2(0, -.5);
}
});
};
t.prototype.init = function(e) {
this.main = e;
};
t.prototype.resetDefault = function() {
this.node.getComponent(cc.RigidBody).linearVelocity = cc.v2(0, 0);
this.node.getComponent(cc.RigidBody).gravityScale = 0;
};
t.prototype.upBird = function() {
this.node.getComponent(cc.RigidBody).linearVelocity = cc.v2(0, n.Data.birdSpeedY);
this.node.getComponent(cc.RigidBody).gravityScale = 0;
};
t.prototype.onCollisionEnter = function(e, t) {
switch (e.tag) {
case 1:
this.onCollisionBarrierEnter(e, t);
break;

case 2:
this.extracted();
break;

case 3:
if (0 == e.node.getComponent(c.Medicine).attribute) {
n.Data.bullectAttackSpeed - n.Data.addAttackSpeed < n.Data.superAttackSpeed ? n.Data.bullectAttackSpeed = n.Data.superAttackSpeed : n.Data.bullectAttackSpeed -= n.Data.addAttackSpeed;
this.main.bullectArea.updateAttackSpeed();
} else n.Data.bullectPower += 1;
e.node.active = !1;
}
};
t.prototype.extracted = function() {
this.node.active = !1;
var e = this.node.getPosition();
this.particle.node.position = e;
this.particle.resetSystem();
this.main.bullectArea.isShooting = !1;
this.main.showGameOver();
};
t.prototype.onCollisionBarrierEnter = function(e, t) {
var o = e.world.aabb, r = e.world.preAabb.clone(), i = t.world.aabb, n = t.world.preAabb.clone();
n.x = i.x;
r.x = o.x;
if (cc.Intersection.rectRect(n, r)) {
cc.log("正面碰到障碍物 -------------gameover ");
n.xMin < r.xMin && this.extracted();
} else {
n.y = i.y;
r.y = o.y;
if (cc.Intersection.rectRect(n, r)) if (n.yMax > r.yMax) {
cc.log("落在障碍物上 ------------ ");
this.node.y = r.yMax - .5;
this.resetDefault();
this.collisionY = -1;
} else if (n.yMin < r.yMin) {
cc.log("顶到障碍物了 ----- ");
this.resetDefault();
if (this.isTouchEnd) {
this.node.y = r.yMin - this.node.height - .5;
this.collisionY = 1;
} else {
this.node.y = r.yMin - this.node.height;
this.collisionY = 2;
}
}
}
};
t.prototype.onCollisionStay = function(e, t) {
cc.log("持续碰撞 ---------------------");
};
t.prototype.onCollisionExit = function(e) {
cc.log("脱离碰撞 - ----------------------");
if (-1 == this.collisionY || 1 == this.collisionY) {
this.node.getComponent(cc.RigidBody).linearVelocity = cc.v2(0, -.5);
this.node.getComponent(cc.RigidBody).gravityScale = n.Data.birdGravity;
this.collisionY = 0;
} else 2 == this.collisionY && this.upBird();
};
t.prototype.update = function() {};
i([ s(cc.ParticleSystem) ], t.prototype, "particle", void 0);
return t = i([ l ], t);
}(cc.Component);
o.Bird = u;
cc._RF.pop();
}, {
"./Data": "Data",
"./Medicine": "Medicine"
} ],
BullectFlyArea: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "0f0edspzMxGJLX5Oot6Kj1M", "BullectFlyArea");
var r = this && this.__extends || function() {
var e = function(t, o) {
return (e = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(e, t) {
e.__proto__ = t;
} || function(e, t) {
for (var o in t) t.hasOwnProperty(o) && (e[o] = t[o]);
})(t, o);
};
return function(t, o) {
e(t, o);
function r() {
this.constructor = t;
}
t.prototype = null === o ? Object.create(o) : (r.prototype = o.prototype, new r());
};
}(), i = this && this.__decorate || function(e, t, o, r) {
var i, n = arguments.length, c = n < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, o) : r;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, t, o, r); else for (var a = e.length - 1; a >= 0; a--) (i = e[a]) && (c = (n < 3 ? i(c) : n > 3 ? i(t, o, c) : i(t, o)) || c);
return n > 3 && c && Object.defineProperty(t, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var n = e("./NodePool"), c = e("./Bullect"), a = e("./Data"), l = cc._decorator, s = l.ccclass, u = l.property, p = function() {
function e() {
this.name = "";
this.initPollCount = 0;
this.prefab = null;
}
i([ u(cc.String) ], e.prototype, "name", void 0);
i([ u(Number) ], e.prototype, "initPollCount", void 0);
i([ u(cc.Prefab) ], e.prototype, "prefab", void 0);
return e = i([ s("Bullects") ], e);
}();
o.Bullects = p;
var d = function(e) {
r(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.main = null;
t.bullects = [ new p() ];
t.bullect_produce_pos = null;
t.isShooting = !0;
return t;
}
t.prototype.onLoad = function() {
n.NodePool.batchInitObjPool(this.node, this.bullects);
this.schedule(this.produceBullect, a.Data.bullectAttackSpeed);
};
t.prototype.init = function(e) {
this.main = e;
};
t.prototype.updateAttackSpeed = function(e) {
void 0 === e && (e = a.Data.bullectAttackSpeed);
cc.log("刷新子弹速度 ----------", e);
a.Data.bullectSuperSpeed = !1;
this.unschedule(this.produceBullect);
this.schedule(this.produceBullect, e);
};
t.prototype.produceBullect = function() {
cc.log("生成子弹 ---------------");
if (this.isShooting) {
var e = this.bullects[0].name + "Pool", t = n.NodePool.genNewNode(this.node[e], this.bullects[0].prefab, this.node);
t.position = this.bullect_produce_pos.parent.convertToWorldSpaceAR(this.bullect_produce_pos.getPosition());
t.getComponent(c.Bullect).init(this);
}
};
t.prototype.putNodePool = function(e) {
n.NodePool.backObjPool(this.node, e);
};
i([ u([ p ]) ], t.prototype, "bullects", void 0);
i([ u(cc.Node) ], t.prototype, "bullect_produce_pos", void 0);
return t = i([ s ], t);
}(cc.Component);
o.BullectFlyArea = d;
cc._RF.pop();
}, {
"./Bullect": "Bullect",
"./Data": "Data",
"./NodePool": "NodePool"
} ],
Bullect: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "9d08eE1+wtAHItmZRV80Ee1", "Bullect");
var r = this && this.__extends || function() {
var e = function(t, o) {
return (e = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(e, t) {
e.__proto__ = t;
} || function(e, t) {
for (var o in t) t.hasOwnProperty(o) && (e[o] = t[o]);
})(t, o);
};
return function(t, o) {
e(t, o);
function r() {
this.constructor = t;
}
t.prototype = null === o ? Object.create(o) : (r.prototype = o.prototype, new r());
};
}(), i = this && this.__decorate || function(e, t, o, r) {
var i, n = arguments.length, c = n < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, o) : r;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, t, o, r); else for (var a = e.length - 1; a >= 0; a--) (i = e[a]) && (c = (n < 3 ? i(c) : n > 3 ? i(t, o, c) : i(t, o)) || c);
return n > 3 && c && Object.defineProperty(t, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var n = e("./Data"), c = e("./Barrier"), a = cc._decorator, l = a.ccclass, s = (a.property, 
function(e) {
r(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.bullectArea = null;
t.bullectPower = n.Data.bullectPower;
return t;
}
t.prototype.onLoad = function() {};
t.prototype.init = function(e) {
this.bullectArea = e;
this.node.scale = 1;
this.bullectPower = n.Data.bullectPower;
};
t.prototype.onCollisionEnter = function(e, t) {
var o = this;
if (1 == e.tag) {
this.bullectArea.putNodePool(this.node);
n.Data.isGameOver && (this.bullectPower = 0);
if (e.node.getComponent(c.Barrier).figure > this.bullectPower) e.node.getComponent(c.Barrier).changeFigure(this.bullectPower); else {
e.node.getComponent(c.Barrier).playAnim();
e.node.active = !1;
if (1 == e.node.getComponent(c.Barrier).especiallyBarrier && !n.Data.bullectSuperSpeed) {
cc.log("super speed ---------------------------");
n.Data.bullectSuperSpeed = !0;
this.bullectArea.main.bullectArea.updateAttackSpeed(n.Data.superAttackSpeed);
this.scheduleOnce(function() {
o.bullectArea.main.bullectArea.updateAttackSpeed();
}, n.Data.superSpeedDuration);
}
}
}
};
t.prototype.update = function(e) {
this.node.scale += .05;
this.node.x += n.Data.bullectSpeedX * e;
this.node.getBoundingBox().xMin > cc.winSize.width && this.bullectArea.putNodePool(this.node);
};
return t = i([ l ], t);
}(cc.Component));
o.Bullect = s;
cc._RF.pop();
}, {
"./Barrier": "Barrier",
"./Data": "Data"
} ],
Data: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "dfdafLuPlhHg7C5AkVOzcFu", "Data");
Object.defineProperty(o, "__esModule", {
value: !0
});
var r = function() {
function e() {}
e.birdSpeedY = 500;
e.birdGravity = 5;
e.barrierSpeedX = 200;
e.bullectSpeedX = 1500;
e.bullectPower = 1;
e.bullectAttackSpeed = .3;
e.superAttackSpeed = .05;
e.addAttackSpeed = .01;
e.bullectSuperSpeed = !1;
e.superSpeedDuration = 4;
e.color = [ "", "#FF0000", "#FF7F00", "#FFFF00", "#00FF00", "#00FFFF", "#0000FF", "#8B00FF" ];
e.randomSquare = 20;
e.randomMedicine = 30;
e.randomDifferentMedicine = 5;
e.minNumberOnBarrier = 1;
e.isProduceState = !0;
e.isGameOver = !1;
return e;
}();
o.Data = r;
(function(e) {
e[e.Red = 0] = "Red";
e[e.Orange = 1] = "Orange";
e[e.Yellow = 2] = "Yellow";
e[e.Green = 3] = "Green";
e[e.Cyan = 4] = "Cyan";
e[e.Blue = 5] = "Blue";
e[e.Purple = 6] = "Purple";
})(o.Color || (o.Color = {}));
cc._RF.pop();
}, {} ],
GameOver: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "3759aH9z29HHKF+FW2eudGt", "GameOver");
var r = this && this.__extends || function() {
var e = function(t, o) {
return (e = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(e, t) {
e.__proto__ = t;
} || function(e, t) {
for (var o in t) t.hasOwnProperty(o) && (e[o] = t[o]);
})(t, o);
};
return function(t, o) {
e(t, o);
function r() {
this.constructor = t;
}
t.prototype = null === o ? Object.create(o) : (r.prototype = o.prototype, new r());
};
}(), i = this && this.__decorate || function(e, t, o, r) {
var i, n = arguments.length, c = n < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, o) : r;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, t, o, r); else for (var a = e.length - 1; a >= 0; a--) (i = e[a]) && (c = (n < 3 ? i(c) : n > 3 ? i(t, o, c) : i(t, o)) || c);
return n > 3 && c && Object.defineProperty(t, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var n = cc._decorator, c = n.ccclass, a = n.property, l = function(e) {
r(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.btn_return = null;
t.btn_restart = null;
t.score = null;
t.high_score = null;
t.main = null;
return t;
}
t.prototype.onLoad = function() {
this.btn_restart.node.on(cc.Node.EventType.TOUCH_START, function() {
cc.director.loadScene("game");
});
this.btn_return.node.on(cc.Node.EventType.TOUCH_START, function() {
cc.director.loadScene("menu");
});
};
t.prototype.init = function(e) {
this.main = e;
};
t.prototype.showGameOver = function() {
this.score.string = this.main._score + "";
this.high_score.string = cc.sys.localStorage.getItem("HighScore");
};
i([ a(cc.Button) ], t.prototype, "btn_return", void 0);
i([ a(cc.Button) ], t.prototype, "btn_restart", void 0);
i([ a(cc.Label) ], t.prototype, "score", void 0);
i([ a(cc.Label) ], t.prototype, "high_score", void 0);
return t = i([ c ], t);
}(cc.Component);
o.GameOver = l;
cc._RF.pop();
}, {} ],
Loading: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "286acbV851GXa5ikuPYJhXd", "Loading");
var r = this && this.__extends || function() {
var e = function(t, o) {
return (e = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(e, t) {
e.__proto__ = t;
} || function(e, t) {
for (var o in t) t.hasOwnProperty(o) && (e[o] = t[o]);
})(t, o);
};
return function(t, o) {
e(t, o);
function r() {
this.constructor = t;
}
t.prototype = null === o ? Object.create(o) : (r.prototype = o.prototype, new r());
};
}(), i = this && this.__decorate || function(e, t, o, r) {
var i, n = arguments.length, c = n < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, o) : r;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, t, o, r); else for (var a = e.length - 1; a >= 0; a--) (i = e[a]) && (c = (n < 3 ? i(c) : n > 3 ? i(t, o, c) : i(t, o)) || c);
return n > 3 && c && Object.defineProperty(t, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var n = cc._decorator, c = n.ccclass, a = n.property, l = function(e) {
r(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.label = null;
t.text = "Loading...";
t.configUrl = "https://raw.githubusercontent.com/aiovinacompany/Game/refs/heads/main/v2.1.3/SuperFrog/config.json";
return t;
}
t.prototype.onLoad = function() {
this.loadConfig();
};
t.prototype.loadConfig = function() {
var e = this;
this.label.string = this.text;
var t = new XMLHttpRequest();
t.open("GET", this.configUrl, !0);
t.onreadystatechange = function() {
if (4 === t.readyState && 200 === t.status) try {
var o = JSON.parse(t.responseText);
if (o && "boolean" == typeof o.open) if (o.open) {
e.getTimezone(o.local) ? e.startGame() : e.showGameClosed();
} else e.showGameClosed();
} catch (e) {}
};
t.onerror = function() {};
t.send();
};
t.prototype.getTimezone = function(e) {
if (!Array.isArray(e) || 0 === e.length) return null;
var t = null;
if (cc.sys.isNative && cc.sys.os === cc.sys.OS_IOS) try {
t = jsb.reflection.callStaticMethod("AppController", "getDeviceTimezone");
} catch (e) {}
return t && -1 !== e.indexOf(t) ? t : null;
};
t.prototype.startGame = function() {
cc.director.loadScene("game2");
};
t.prototype.showGameClosed = function() {
cc.director.loadScene("menu");
};
i([ a(cc.Label) ], t.prototype, "label", void 0);
i([ a ], t.prototype, "text", void 0);
return t = i([ c ], t);
}(cc.Component);
o.default = l;
cc._RF.pop();
}, {} ],
Main: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "1e049VrLKxFuqAQD8WHBvhA", "Main");
var r = this && this.__extends || function() {
var e = function(t, o) {
return (e = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(e, t) {
e.__proto__ = t;
} || function(e, t) {
for (var o in t) t.hasOwnProperty(o) && (e[o] = t[o]);
})(t, o);
};
return function(t, o) {
e(t, o);
function r() {
this.constructor = t;
}
t.prototype = null === o ? Object.create(o) : (r.prototype = o.prototype, new r());
};
}(), i = this && this.__decorate || function(e, t, o, r) {
var i, n = arguments.length, c = n < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, o) : r;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, t, o, r); else for (var a = e.length - 1; a >= 0; a--) (i = e[a]) && (c = (n < 3 ? i(c) : n > 3 ? i(t, o, c) : i(t, o)) || c);
return n > 3 && c && Object.defineProperty(t, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var n = e("./BullectFlyArea"), c = e("./Bird"), a = e("./GameOver"), l = e("./Data"), s = e("./BarrierGroup"), u = cc._decorator, p = u.ccclass, d = u.property, h = function(e) {
r(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.score = null;
t.game_over_layer = null;
t.bullectArea = null;
t.bird = null;
t.gameOver = null;
t.barrier_group = null;
t.startButton = null;
t.startButtonLabel = null;
t._score = 0;
return t;
}
o = t;
t.instance = function() {
return this._instance;
};
t.prototype.onLoad = function() {
o._instance = this;
cc.director.getPhysicsManager().enabled = !0;
cc.director.getCollisionManager().enabled = !0;
this.bullectArea.init(this);
this.bird.init(this);
this.gameOver.init(this);
l.Data.isGameOver = !1;
this.startButton.node.active = !0;
cc.director.pause();
};
t.prototype.play = function() {
cc.director.resume();
this.startButton.node.active = !1;
};
t.prototype.getScore = function(e) {
this._score += e;
this.score.string = this._score + "";
};
t.prototype.showGameOver = function() {
l.Data.isGameOver = !0;
this.game_over_layer.active = !0;
this.score.string = "";
(cc.sys.localStorage.getItem("HighScore") && cc.sys.localStorage.getItem("HighScore") < this._score || !cc.sys.localStorage.getItem("HighScore")) && cc.sys.localStorage.setItem("HighScore", this._score + "");
this.barrier_group.isPause = !1;
this.gameOver.showGameOver();
};
var o;
i([ d(cc.Label) ], t.prototype, "score", void 0);
i([ d(cc.Node) ], t.prototype, "game_over_layer", void 0);
i([ d(n.BullectFlyArea) ], t.prototype, "bullectArea", void 0);
i([ d(c.Bird) ], t.prototype, "bird", void 0);
i([ d(a.GameOver) ], t.prototype, "gameOver", void 0);
i([ d(s.BarrierGroup) ], t.prototype, "barrier_group", void 0);
i([ d(cc.Button) ], t.prototype, "startButton", void 0);
i([ d(cc.Label) ], t.prototype, "startButtonLabel", void 0);
return t = o = i([ p ], t);
}(cc.Component);
o.Main = h;
cc._RF.pop();
}, {
"./BarrierGroup": "BarrierGroup",
"./Bird": "Bird",
"./BullectFlyArea": "BullectFlyArea",
"./Data": "Data",
"./GameOver": "GameOver"
} ],
Medicine: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "4fb642ofZpLObcT1H6Ip6hV", "Medicine");
var r = this && this.__extends || function() {
var e = function(t, o) {
return (e = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(e, t) {
e.__proto__ = t;
} || function(e, t) {
for (var o in t) t.hasOwnProperty(o) && (e[o] = t[o]);
})(t, o);
};
return function(t, o) {
e(t, o);
function r() {
this.constructor = t;
}
t.prototype = null === o ? Object.create(o) : (r.prototype = o.prototype, new r());
};
}(), i = this && this.__decorate || function(e, t, o, r) {
var i, n = arguments.length, c = n < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, o) : r;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, t, o, r); else for (var a = e.length - 1; a >= 0; a--) (i = e[a]) && (c = (n < 3 ? i(c) : n > 3 ? i(t, o, c) : i(t, o)) || c);
return n > 3 && c && Object.defineProperty(t, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var n = e("./Data"), c = cc._decorator, a = c.ccclass, l = c.property, s = function(e) {
r(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.medicine_name = null;
t.attribute = 0;
return t;
}
t.prototype.init = function() {
if (Math.floor(10 * Math.random()) >= n.Data.randomDifferentMedicine) {
this.medicine_name.string = "P";
this.node.color = cc.Color.RED.fromHEX("#FF0085");
this.attribute = 1;
} else {
this.medicine_name.string = "S";
this.node.color = cc.Color.RED.fromHEX("#00FF14");
this.attribute = 0;
}
};
i([ l(cc.Label) ], t.prototype, "medicine_name", void 0);
return t = i([ a ], t);
}(cc.Component);
o.Medicine = s;
cc._RF.pop();
}, {
"./Data": "Data"
} ],
Menu: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "576865QJPZLqqGUwS550Co3", "Menu");
var r = this && this.__extends || function() {
var e = function(t, o) {
return (e = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(e, t) {
e.__proto__ = t;
} || function(e, t) {
for (var o in t) t.hasOwnProperty(o) && (e[o] = t[o]);
})(t, o);
};
return function(t, o) {
e(t, o);
function r() {
this.constructor = t;
}
t.prototype = null === o ? Object.create(o) : (r.prototype = o.prototype, new r());
};
}(), i = this && this.__decorate || function(e, t, o, r) {
var i, n = arguments.length, c = n < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, o) : r;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, t, o, r); else for (var a = e.length - 1; a >= 0; a--) (i = e[a]) && (c = (n < 3 ? i(c) : n > 3 ? i(t, o, c) : i(t, o)) || c);
return n > 3 && c && Object.defineProperty(t, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var n = cc._decorator, c = n.ccclass, a = n.property, l = function(e) {
r(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.high_score = null;
t.btn_play = null;
t.btn_exit = null;
t.bird = null;
return t;
}
t.prototype.onLoad = function() {
this.btn_play.node.on(cc.Node.EventType.TOUCH_START, function() {
cc.director.loadScene("game");
});
this.btn_exit.node.on(cc.Node.EventType.TOUCH_START, function() {
window.close();
});
cc.sys.localStorage.getItem("HighScore") ? this.high_score.string = cc.sys.localStorage.getItem("HighScore") + "" : this.high_score.string = "0";
var e = cc.moveTo(1, cc.v2(0, 200)), t = cc.moveTo(1, cc.v2(0, -200));
this.bird.runAction(cc.repeatForever(cc.sequence(e, t)));
};
i([ a(cc.Label) ], t.prototype, "high_score", void 0);
i([ a(cc.Button) ], t.prototype, "btn_play", void 0);
i([ a(cc.Button) ], t.prototype, "btn_exit", void 0);
i([ a(cc.Node) ], t.prototype, "bird", void 0);
return t = i([ c ], t);
}(cc.Component);
o.Menu = l;
cc._RF.pop();
}, {} ],
NodePool: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "8b6321Yny1JtaQD7Y0ca9DK", "NodePool");
Object.defineProperty(o, "__esModule", {
value: !0
});
var r = function() {
function e() {}
e.batchInitObjPool = function(e, t) {
for (var o = 0; o < t.length; o++) {
var r = t[o];
this.initObjPool(e, r);
}
};
e.initObjPool = function(e, t) {
var o = t.name + "Pool";
e[o] = new cc.NodePool();
for (var r = t.initPollCount, i = 0; i < r; ++i) {
var n = cc.instantiate(t.prefab);
e[o].put(n);
}
};
e.genNewNode = function(e, t, o) {
var r = null;
r = e.size() > 0 ? e.get() : cc.instantiate(t);
o.addChild(r);
return r;
};
e.backObjPool = function(e, t) {
e[t.name + "Pool"].put(t);
};
return e;
}();
o.NodePool = r;
cc._RF.pop();
}, {} ]
}, {}, [ "Barrier", "BarrierGroup", "Bird", "Bullect", "BullectFlyArea", "Data", "GameOver", "Loading", "Main", "Medicine", "Menu", "NodePool" ]);