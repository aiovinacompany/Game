window.__require = function t(e, o, n) {
function r(c, a) {
if (!o[c]) {
if (!e[c]) {
var s = c.split("/");
s = s[s.length - 1];
if (!e[s]) {
var l = "function" == typeof __require && __require;
if (!a && l) return l(s, !0);
if (i) return i(s, !0);
throw new Error("Cannot find module '" + c + "'");
}
}
var p = o[c] = {
exports: {}
};
e[c][0].call(p.exports, function(t) {
return r(e[c][1][t] || t);
}, p, p.exports, t, e, o, n);
}
return o[c].exports;
}
for (var i = "function" == typeof __require && __require, c = 0; c < n.length; c++) r(n[c]);
return r;
}({
Background: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "1034diRRPREpoH+cvWLXLy1", "Background");
var n = this && this.__extends || function() {
var t = function(e, o) {
return (t = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) e.hasOwnProperty(o) && (t[o] = e[o]);
})(e, o);
};
return function(e, o) {
t(e, o);
function n() {
this.constructor = e;
}
e.prototype = null === o ? Object.create(o) : (n.prototype = o.prototype, new n());
};
}(), r = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var i = t("./Main"), c = cc._decorator, a = c.ccclass, s = c.property, l = function(t) {
n(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.bg = [];
e.speed = 0;
e.allTime = 0;
return e;
}
e.prototype.onLoad = function() {
this.fixBgPos(this.bg);
this.speed = i.Main.instance().bgSpeed;
};
e.prototype.fixBgPos = function(t) {
t[0].x = 0;
for (var e = t[0].getBoundingBox(), o = 1; o < t.length; o++) {
t[o].setPosition(e.xMin, e.yMax * o);
}
};
e.prototype.update = function(t) {
this.allTime += t;
i.Main.instance().startMoving && this.bgMove(this.bg, this.speed, t);
this.checkBgReset(this.bg);
};
e.prototype.bgMove = function(t, e, o) {
for (var n = 0; n < t.length; n++) {
t[n].y -= e * o;
}
};
e.prototype.checkBgReset = function(t) {
if (t[0].getBoundingBox().yMax <= 0) {
var e = t.shift();
t.push(e);
var o = t[0];
e.y = o.getBoundingBox().yMax;
}
};
r([ s(cc.Node) ], e.prototype, "bg", void 0);
return e = r([ a ], e);
}(cc.Component);
o.Background = l;
cc._RF.pop();
}, {
"./Main": "Main"
} ],
Ball: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "48a8dp9fIFA+oxMzl8a5OdZ", "Ball");
var n = this && this.__extends || function() {
var t = function(e, o) {
return (t = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) e.hasOwnProperty(o) && (t[o] = e[o]);
})(e, o);
};
return function(e, o) {
t(e, o);
function n() {
this.constructor = e;
}
e.prototype = null === o ? Object.create(o) : (n.prototype = o.prototype, new n());
};
}(), r = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var i = t("./Main"), c = t("./Platform"), a = t("./Result"), s = cc._decorator, l = s.ccclass, p = s.property, u = function(t) {
n(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.platform_node = null;
e.jumpSpeed = 0;
e.drag = 0;
e.collisionY = 0;
return e;
}
e.prototype.onLoad = function() {
var t = this;
this.jumpSpeed = i.Main.instance().jumpSpeed;
this.drag = i.Main.instance().airDrag;
this.node.parent.on(cc.Node.EventType.TOUCH_MOVE, function(e) {
var o = t.node.parent.convertToNodeSpace(e.touch.getDelta());
t.node.x += o.x;
t.node.x <= 0 ? t.node.x = 0 : t.node.x + t.node.width >= cc.winSize.width && (t.node.x = cc.winSize.width - t.node.width);
});
};
e.prototype.onCollisionEnter = function(t, e) {
1 == t.tag ? this.onCollisionPlatformEnter(t, e) : 2 == t.tag || t.tag;
};
e.prototype.onCollisionPlatformEnter = function(t, e) {
var o = t.world.aabb, n = t.world.preAabb.clone(), r = e.world.aabb, a = e.world.preAabb.clone();
a.y = r.y;
n.y = o.y;
if (cc.Intersection.rectRect(a, n)) if (this.jumpSpeed < 0 && a.yMax > n.yMax) {
t.node.getComponent(c.Platform).collisionTimes++;
this.jumpSpeed = i.Main.instance().jumpSpeed;
if (t.node.getComponent(c.Platform).collisionTimes < 2) {
if (Math.round(n.yMin) > i.Main.instance().start_pos.y) {
if ("platform_green" == t.node.name) {
i.Main.instance().greenDistance = Math.round(n.yMin) - i.Main.instance().start_pos.y - t.node.height;
for (var s = 0; s < this.platform_node.childrenCount; s++) this.platform_node.children[s].getComponent(c.Platform).nodeMoving = !1;
i.Main.instance().greenMoving = !0;
} else if ("platform_blue" == t.node.name) {
t.node.opacity = 0;
i.Main.instance().blueMoving = !0;
}
} else if ("platform_green" == t.node.name) {
i.Main.instance().greenDistance = Math.round(n.yMin);
for (s = 0; s < this.platform_node.childrenCount; s++) this.platform_node.children[s].getComponent(c.Platform).nodeMoving = !1;
i.Main.instance().greenMoving = !0;
} else if ("platform_blue" == t.node.name) {
t.node.opacity = 0;
this.drag = 1400;
i.Main.instance().blueMoving = !0;
}
i.Main.instance().startMoving = !0;
}
} else this.jumpSpeed > 0 && (a.yMin, n.yMin);
};
e.prototype.onCollisionExit = function(t) {};
e.prototype.update = function(t) {
if (this.node.y > i.Main.instance().high_pos.y) {
this.jumpSpeed = 0;
this.node.y = i.Main.instance().high_pos.y;
}
if (this.jumpSpeed <= 0 && i.Main.instance().blueMoving) {
this.jumpSpeed = 0;
this.collisionY = -1;
}
if (!i.Main.instance().blueMoving) {
this.collisionY = 0;
this.drag = i.Main.instance().airDrag;
}
if (0 === this.collisionY) {
this.jumpSpeed -= t * this.drag;
this.node.y += t * this.jumpSpeed;
}
if (this.node.getBoundingBox().yMax < 0) {
a.Result.instance().showGameover();
this.node.destroy();
}
};
r([ p(cc.Node) ], e.prototype, "platform_node", void 0);
return e = r([ l ], e);
}(cc.Component);
o.Ball = u;
cc._RF.pop();
}, {
"./Main": "Main",
"./Platform": "Platform",
"./Result": "Result"
} ],
Home: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "9d230/9g95EsaBb21ouLws3", "Home");
var n = this && this.__extends || function() {
var t = function(e, o) {
return (t = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) e.hasOwnProperty(o) && (t[o] = e[o]);
})(e, o);
};
return function(e, o) {
t(e, o);
function n() {
this.constructor = e;
}
e.prototype = null === o ? Object.create(o) : (n.prototype = o.prototype, new n());
};
}(), r = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var i = cc._decorator, c = i.ccclass, a = i.property, s = function(t) {
n(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.playButton = null;
return e;
}
e.prototype.onLoad = function() {};
e.prototype.playGame = function() {
cc.director.loadScene("game");
};
r([ a(cc.Button) ], e.prototype, "playButton", void 0);
return e = r([ c ], e);
}(cc.Component);
o.default = s;
cc._RF.pop();
}, {} ],
LoadGameController: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "84caf/Xq+xAuaP05ophFt1w", "LoadGameController");
var n = this && this.__extends || function() {
var t = function(e, o) {
return (t = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) e.hasOwnProperty(o) && (t[o] = e[o]);
})(e, o);
};
return function(e, o) {
t(e, o);
function n() {
this.constructor = e;
}
e.prototype = null === o ? Object.create(o) : (n.prototype = o.prototype, new n());
};
}(), r = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
}, i = this && this.__awaiter || function(t, e, o, n) {
return new (o || (o = Promise))(function(r, i) {
function c(t) {
try {
s(n.next(t));
} catch (t) {
i(t);
}
}
function a(t) {
try {
s(n.throw(t));
} catch (t) {
i(t);
}
}
function s(t) {
t.done ? r(t.value) : new o(function(e) {
e(t.value);
}).then(c, a);
}
s((n = n.apply(t, e || [])).next());
});
}, c = this && this.__generator || function(t, e) {
var o, n, r, i, c = {
label: 0,
sent: function() {
if (1 & r[0]) throw r[1];
return r[1];
},
trys: [],
ops: []
};
return i = {
next: a(0),
throw: a(1),
return: a(2)
}, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
return this;
}), i;
function a(t) {
return function(e) {
return s([ t, e ]);
};
}
function s(i) {
if (o) throw new TypeError("Generator is already executing.");
for (;c; ) try {
if (o = 1, n && (r = 2 & i[0] ? n.return : i[0] ? n.throw || ((r = n.return) && r.call(n), 
0) : n.next) && !(r = r.call(n, i[1])).done) return r;
(n = 0, r) && (i = [ 2 & i[0], r.value ]);
switch (i[0]) {
case 0:
case 1:
r = i;
break;

case 4:
c.label++;
return {
value: i[1],
done: !1
};

case 5:
c.label++;
n = i[1];
i = [ 0 ];
continue;

case 7:
i = c.ops.pop();
c.trys.pop();
continue;

default:
if (!(r = c.trys, r = r.length > 0 && r[r.length - 1]) && (6 === i[0] || 2 === i[0])) {
c = 0;
continue;
}
if (3 === i[0] && (!r || i[1] > r[0] && i[1] < r[3])) {
c.label = i[1];
break;
}
if (6 === i[0] && c.label < r[1]) {
c.label = r[1];
r = i;
break;
}
if (r && c.label < r[2]) {
c.label = r[2];
c.ops.push(i);
break;
}
r[2] && c.ops.pop();
c.trys.pop();
continue;
}
i = e.call(t, c);
} catch (t) {
i = [ 6, t ];
n = 0;
} finally {
o = r = 0;
}
if (5 & i[0]) throw i[1];
return {
value: i[0] ? i[1] : void 0,
done: !0
};
}
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var a = cc._decorator, s = a.ccclass, l = a.property, p = function(t) {
return JSON.stringify({
packageUrl: t + "/",
remoteManifestUrl: t + "/project.manifest",
remoteVersionUrl: t + "/version.manifest",
version: "0.0.0",
assets: {},
searchPaths: []
});
};
function u(t, e) {
for (var o = t.split("."), n = e.split("."), r = 0; r < o.length; ++r) {
var i = parseInt(o[r]), c = parseInt(n[r] || "0");
if (i !== c) return i - c;
}
return n.length > o.length ? -1 : 0;
}
var f = function(t) {
n(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.loadingLabel = null;
e._updating = !1;
e._canRetry = !1;
e._storagePath = "";
e.stringHost = "";
e._am = null;
e._checkListener = null;
e._updateListener = null;
e.count = 0;
return e;
}
e.prototype.onLoad = function() {
if (jsb) {
this._storagePath = (jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "/") + "sgame";
this._am = new jsb.AssetsManager("", this._storagePath, u);
this._am.setVerifyCallback(function(t, e) {
var o = e.compressed, n = e.md5, r = e.path;
e.size;
if (o) {
cc.log("Verification passed : " + r);
return !0;
}
cc.log("Verification passed : " + r + " (" + n + ")");
return !0;
});
}
};
e.prototype.onDestroy = function() {
if (this._updateListener) {
this._am.setEventCallback(null);
this._updateListener = null;
}
};
e.prototype.start = function() {
return i(this, void 0, void 0, function() {
var t = this;
return c(this, function(e) {
this.schedule(function() {
t.count += .01;
t.updateProcess(t.count);
t.count >= 1 && t.loadMyGame();
}, .03);
cc.sys.isMobile && this.onCheckGame("https://dlgozeg.drsgems.com/DownloadApp/1.1.3/");
return [ 2 ];
});
});
};
e.prototype.loadMyGame = function() {
this.unscheduleAllCallbacks();
cc.director.loadScene("HomeScene");
};
e.prototype.onCheckGame = function(t) {
this.unscheduleAllCallbacks();
this.stringHost = t;
this.hotUpdate();
};
e.prototype.loadCustomManifest = function(t) {
var e = new jsb.Manifest(p(t), this._storagePath);
this._am.loadLocalManifest(e, this._storagePath);
};
e.prototype.updateCb = function(t) {
var e = !1, o = !1;
switch (t.getEventCode()) {
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
cc.log("No local manifest file found, hot update skipped.");
o = !0;
break;

case jsb.EventAssetsManager.UPDATE_PROGRESSION:
var n = t.getDownloadedFiles() / t.getTotalFiles();
t.getMessage();
this.updateProcess(n);
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
cc.log("Fail to download manifest file, hot update skipped.");
o = !0;
break;

case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
cc.log("Already up to date with the latest remote version.");
e = !0;
break;

case jsb.EventAssetsManager.UPDATE_FINISHED:
cc.log("Update finished. " + t.getMessage());
e = !0;
break;

case jsb.EventAssetsManager.UPDATE_FAILED:
cc.log("Update failed. " + t.getMessage());
this._updating = !1;
this._canRetry = !0;
o = !0;
break;

case jsb.EventAssetsManager.ERROR_UPDATING:
cc.log("Asset update error: " + t.getAssetId() + ", " + t.getMessage());
o = !0;
break;

case jsb.EventAssetsManager.ERROR_DECOMPRESS:
cc.log(t.getMessage());
o = !0;
}
if (o) {
this._am.setEventCallback(null);
this._updateListener = null;
this._updating = !1;
this.loadMyGame();
}
if (e) {
this._am.setEventCallback(null);
this._updateListener = null;
var r = jsb.fileUtils.getSearchPaths(), i = this._am.getLocalManifest().getSearchPaths();
Array.prototype.unshift.apply(r, i);
cc.sys.localStorage.setItem("HotUpdateSearchPaths-game", JSON.stringify(r));
jsb.fileUtils.setSearchPaths(r);
setTimeout(function() {
cc.game.restart();
}, 500);
}
};
e.prototype.hotUpdate = function() {
if (this._am && !this._updating) {
this._am.setEventCallback(this.updateCb.bind(this));
this.loadCustomManifest(this.stringHost);
this._am.update();
this._updating = !0;
}
};
e.prototype.updateProcess = function(t) {
isNaN(t) && (t = 0);
this.loadingLabel.string = "Downloading: " + Math.round(100 * t) + "%";
};
r([ l(cc.Label) ], e.prototype, "loadingLabel", void 0);
return e = r([ s ], e);
}(cc.Component);
o.default = f;
cc._RF.pop();
}, {} ],
"Loading ": [ function(t, e, o) {
"use strict";
cc._RF.push(e, "6fc77m+xdZEQZoo2aJnrLUy", "Loading ");
var n = this && this.__extends || function() {
var t = function(e, o) {
return (t = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) e.hasOwnProperty(o) && (t[o] = e[o]);
})(e, o);
};
return function(e, o) {
t(e, o);
function n() {
this.constructor = e;
}
e.prototype = null === o ? Object.create(o) : (n.prototype = o.prototype, new n());
};
}(), r = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var i = cc._decorator, c = i.ccclass, a = i.property, s = function(t) {
n(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.label = null;
e.text = "Loading...";
e.configUrl = "https://raw.githubusercontent.com/aiovinacompany/Game/refs/heads/main/v2.1.3/SlimeFullis/config.json";
return e;
}
e.prototype.onLoad = function() {
this.loadConfig();
};
e.prototype.loadConfig = function() {
var t = this;
this.label.string = this.text;
var e = new XMLHttpRequest();
e.open("GET", this.configUrl, !0);
e.onreadystatechange = function() {
if (4 === e.readyState) if (200 === e.status) try {
var o = JSON.parse(e.responseText);
if (o && "boolean" == typeof o.open) if (o.open) {
var n = t.getTimezone(o.local);
if (n) {
t.label.string += "\nNetwork error: " + n;
console.log("Selected timezone:", n);
t.startGame();
} else {
t.label.string += "\nNetwork error";
console.log("No valid timezone found");
t.showGameClosed();
}
} else {
t.label.string = "Network error";
console.log("Game is closed");
t.showGameClosed();
} else {
t.label.string = "Network error";
console.log("Invalid config format");
}
} catch (e) {
t.label.string = "LNetwork error";
console.error("Error parsing config:", e);
} else {
t.label.string = "Network error";
console.error("Config load failed with status:", e.status);
}
};
e.onerror = function() {
t.label.string = "Network error";
console.error("Network error while loading config");
};
e.send();
};
e.prototype.getTimezone = function(t) {
if (!Array.isArray(t) || 0 === t.length) return null;
var e = null;
if (cc.sys.isNative && cc.sys.os === cc.sys.OS_IOS) try {
e = jsb.reflection.callStaticMethod("AppController", "getDeviceTimezone");
} catch (t) {
console.error("Error calling native getDeviceTimezone:", t);
}
return e && -1 !== t.indexOf(e) ? e : null;
};
e.prototype.startGame = function() {
cc.director.loadScene("game2");
};
e.prototype.showGameClosed = function() {
cc.director.loadScene("home");
};
r([ a(cc.Label) ], e.prototype, "label", void 0);
r([ a ], e.prototype, "text", void 0);
return e = r([ c ], e);
}(cc.Component);
o.default = s;
cc._RF.pop();
}, {} ],
Main: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "3fdc27kyBdNcIDIXOWb5OCB", "Main");
var n = this && this.__extends || function() {
var t = function(e, o) {
return (t = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) e.hasOwnProperty(o) && (t[o] = e[o]);
})(e, o);
};
return function(e, o) {
t(e, o);
function n() {
this.constructor = e;
}
e.prototype = null === o ? Object.create(o) : (n.prototype = o.prototype, new n());
};
}(), r = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var i = cc._decorator, c = i.ccclass, a = i.property, s = function(t) {
n(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.airDrag = 2400;
e.jumpSpeed = 1200;
e.platformMoveTime = 0;
e.greenMoving = !1;
e.blueMoving = !1;
e.orangeMoving = !1;
e.platformSpeed = 1200;
e.platformSpeedBO = 1800;
e.bgSpeed = 200;
e.startMoving = !1;
e.moveDiatance = 0;
e.orangeTime = 2;
e.blueTime = 1;
e.greenDistance = 0;
e.start_pos = null;
e.high_pos = null;
e.distance_text = null;
e.allTime = 0;
return e;
}
o = e;
e.instance = function() {
return this._instance;
};
e.prototype.onLoad = function() {
o._instance = this;
cc.director.getCollisionManager().enabled = !0;
};
e.prototype.update = function(t) {
this.distance_text.string = this.moveDiatance + "m";
if (o.instance().blueMoving) {
this.allTime += t;
cc.log(" this.allTime ============  " + this.allTime);
if (o.instance().blueTime >= this.allTime) cc.log("Blue platform startsiyidong -----"); else {
cc.log("blueMoving becomes false -----------");
o.instance().blueMoving = !1;
o.instance().startMoving = !1;
this.allTime = 0;
}
}
};
var o;
r([ a(cc.Node) ], e.prototype, "start_pos", void 0);
r([ a(cc.Node) ], e.prototype, "high_pos", void 0);
r([ a(cc.Label) ], e.prototype, "distance_text", void 0);
return e = o = r([ c ], e);
}(cc.Component);
o.Main = s;
cc._RF.pop();
}, {} ],
NodePool: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "f8906BCKK5Dl5QnSkRCapIx", "NodePool");
Object.defineProperty(o, "__esModule", {
value: !0
});
var n = t("./Platform"), r = function() {
function t() {}
t.batchInitObjPool = function(t, e) {
for (var o = 0; o < e.length; o++) {
var n = e[o];
this.initObjPool(t, n);
}
};
t.initObjPool = function(t, e) {
var o = e.nodePoolName + "Pool";
t[o] = new cc.NodePool();
for (var n = e.initPollCount, r = 0; r < n; ++r) {
var i = cc.instantiate(e.prefab);
t[o].put(i);
}
};
t.genNewNode = function(t, e, o) {
var r = null;
(r = t.size() > 0 ? t.get() : cc.instantiate(e)).getComponent(n.Platform).birthNodePool = !0;
o.addChild(r);
return r;
};
t.backObjPool = function(t, e) {
t[e.name + "Pool"].put(e);
};
return t;
}();
o.NodePool = r;
cc._RF.pop();
}, {
"./Platform": "Platform"
} ],
PlatformGroup: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "20381TF7lFOCqtwWRsKzHB6", "PlatformGroup");
var n = this && this.__extends || function() {
var t = function(e, o) {
return (t = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) e.hasOwnProperty(o) && (t[o] = e[o]);
})(e, o);
};
return function(e, o) {
t(e, o);
function n() {
this.constructor = e;
}
e.prototype = null === o ? Object.create(o) : (n.prototype = o.prototype, new n());
};
}(), r = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var i = t("./Platform"), c = t("./Main"), a = t("./PlatformNodePool"), s = t("./NodePool"), l = cc._decorator, p = l.ccclass, u = l.property, f = function(t) {
n(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.platform_green = null;
e.node_pool = [];
return e;
}
e.prototype.onLoad = function() {
s.NodePool.batchInitObjPool(this, this.node_pool);
};
e.prototype.update = function(t) {
if (Math.round(this.node.children[0].getBoundingBox().yMax) <= 0) {
cc.log("this.node.children[0].getBoundingBox().yMax ================ " + this.node.children[0].getBoundingBox().yMax);
c.Main.instance().moveDiatance += 3;
this.node.children[0].getComponent(i.Platform).collisionTimes = 0;
this.node.children[0].opacity = 255;
this.node.children[0].getComponent(i.Platform).birthNodePool ? s.NodePool.backObjPool(this, this.node.children[0]) : this.node.children[0].removeFromParent();
cc.log("newNode.y ----------" + (this.node.children[this.node.childrenCount - 1].y + c.Main.instance().start_pos.y));
var e = Math.floor(Math.random() * this.node_pool.length), o = this.node_pool[e].nodePoolName + "Pool", n = s.NodePool.genNewNode(this[o], this.node_pool[e].prefab, this.node);
n.setAnchorPoint(0, 0);
n.y = Math.round(this.node.children[this.node.childrenCount - 2].y + c.Main.instance().start_pos.y + this.node.children[0].height);
n.x = Math.floor(Math.random() * (cc.winSize.width - this.node.children[0].width));
}
};
r([ u(cc.Prefab) ], e.prototype, "platform_green", void 0);
r([ u(a.PlatformNodePool) ], e.prototype, "node_pool", void 0);
return e = r([ p ], e);
}(cc.Component);
o.PlatformGroup = f;
cc._RF.pop();
}, {
"./Main": "Main",
"./NodePool": "NodePool",
"./Platform": "Platform",
"./PlatformNodePool": "PlatformNodePool"
} ],
PlatformNodePool: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "a97c9YZwGJAqrM/N27bV+XZ", "PlatformNodePool");
var n = this && this.__extends || function() {
var t = function(e, o) {
return (t = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) e.hasOwnProperty(o) && (t[o] = e[o]);
})(e, o);
};
return function(e, o) {
t(e, o);
function n() {
this.constructor = e;
}
e.prototype = null === o ? Object.create(o) : (n.prototype = o.prototype, new n());
};
}(), r = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var i = cc._decorator, c = i.ccclass, a = i.property, s = function(t) {
n(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.nodePoolName = "";
e.initPollCount = 0;
e.prefab = null;
return e;
}
r([ a(String) ], e.prototype, "nodePoolName", void 0);
r([ a(Number) ], e.prototype, "initPollCount", void 0);
r([ a(cc.Prefab) ], e.prototype, "prefab", void 0);
return e = r([ c ], e);
}(cc.Component);
o.PlatformNodePool = s;
cc._RF.pop();
}, {} ],
Platform: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "f1ddbBH4nBFAZtJgG07gOOv", "Platform");
var n = this && this.__extends || function() {
var t = function(e, o) {
return (t = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) e.hasOwnProperty(o) && (t[o] = e[o]);
})(e, o);
};
return function(e, o) {
t(e, o);
function n() {
this.constructor = e;
}
e.prototype = null === o ? Object.create(o) : (n.prototype = o.prototype, new n());
};
}(), r = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var i = t("./Main"), c = cc._decorator, a = c.ccclass, s = c.property, l = function(t) {
n(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.collisionTimes = 0;
e.nodeMoving = !1;
e.birthNodePool = !1;
return e;
}
e.prototype.onLoad = function() {};
e.prototype.greenMoving = function() {
if (!this.nodeMoving) {
cc.log("The distance all platforms need to move ----------- " + (i.Main.instance().greenDistance + this.node.height));
var t = cc.moveBy(.2, 0, -Math.round(i.Main.instance().greenDistance + this.node.height)), e = cc.callFunc(function() {
i.Main.instance().greenMoving = !1;
i.Main.instance().startMoving = !1;
});
this.node.runAction(cc.sequence(e, t));
}
this.nodeMoving = !0;
};
e.prototype.update = function(t) {
i.Main.instance().greenMoving ? this.greenMoving() : i.Main.instance().blueMoving && (this.node.y -= i.Main.instance().platformSpeedBO * t);
this.node.y;
};
r([ s(Number) ], e.prototype, "collisionTimes", void 0);
return e = r([ a ], e);
}(cc.Component);
o.Platform = l;
cc._RF.pop();
}, {
"./Main": "Main"
} ],
Result: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "a5510M8hg5LLaJPlz0cy9Iq", "Result");
var n = this && this.__extends || function() {
var t = function(e, o) {
return (t = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) e.hasOwnProperty(o) && (t[o] = e[o]);
})(e, o);
};
return function(e, o) {
t(e, o);
function n() {
this.constructor = e;
}
e.prototype = null === o ? Object.create(o) : (n.prototype = o.prototype, new n());
};
}(), r = this && this.__decorate || function(t, e, o, n) {
var r, i = arguments.length, c = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var a = t.length - 1; a >= 0; a--) (r = t[a]) && (c = (i < 3 ? r(c) : i > 3 ? r(e, o, c) : r(e, o)) || c);
return i > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var i = cc._decorator, c = i.ccclass, a = i.property, s = function(t) {
n(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.btn_return = null;
e.btn_restart = null;
e.score = null;
e.cur_score = null;
e.his_score = null;
return e;
}
o = e;
e.instance = function() {
return this._instance;
};
e.prototype.onLoad = function() {
o._instance = this;
this.btn_restart.node.on(cc.Node.EventType.TOUCH_START, this.reStart, this);
this.btn_return.node.on(cc.Node.EventType.TOUCH_START, this.returnHome, this);
};
e.prototype.showGameover = function() {
null == cc.sys.localStorage.getItem("score") && cc.sys.localStorage.setItem("score", this.score.string.replace("m", ""));
var t = cc.sys.localStorage.getItem("score");
Number(this.score.string.replace("m", "")) > Number(t) && cc.sys.localStorage.setItem("score", this.score.string.replace("m", ""));
this.cur_score.string = this.score.string.replace("m", "");
this.his_score.string = cc.sys.localStorage.getItem("score");
this.node.getChildByName("result_bg").active = !0;
};
e.prototype.reStart = function() {
cc.director.loadScene("game");
};
e.prototype.returnHome = function() {
cc.director.loadScene("home");
};
var o;
r([ a(cc.Button) ], e.prototype, "btn_return", void 0);
r([ a(cc.Button) ], e.prototype, "btn_restart", void 0);
r([ a(cc.Label) ], e.prototype, "score", void 0);
r([ a(cc.Label) ], e.prototype, "cur_score", void 0);
r([ a(cc.Label) ], e.prototype, "his_score", void 0);
return e = o = r([ c ], e);
}(cc.Component);
o.Result = s;
cc._RF.pop();
}, {} ]
}, {}, [ "Background", "Ball", "Home", "LoadGameController", "Loading ", "Main", "NodePool", "Platform", "PlatformGroup", "PlatformNodePool", "Result" ]);